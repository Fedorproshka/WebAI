// Центральные типы данных платформы.
// ВАЖНО: любое блюдо/ресторан всегда привязаны к restaurantId — это и есть
// граница multi-tenant изоляции на уровне приложения (дублируется RLS в БД).

export interface Restaurant {
  id: string;
  slug: string;
  name: string;
  description: string;
  logoUrl: string | null;
  currency: string; // напр. "₸"
  createdAt: string;
}

export interface Category {
  id: string;
  restaurantId: string;
  name: string;
  sortOrder: number;
}

export type Allergen =
  | 'gluten'
  | 'dairy'
  | 'eggs'
  | 'nuts'
  | 'peanuts'
  | 'fish'
  | 'shellfish'
  | 'soy'
  | 'sesame';

export type DishTag =
  | 'meat'
  | 'fish'
  | 'pasta'
  | 'light'
  | 'vegetarian'
  | 'vegan'
  | 'spicy'
  | 'mild'
  | 'dessert'
  | 'drink'
  | 'soup'
  | 'salad'
  | 'breakfast';

export interface Dish {
  id: string;
  restaurantId: string;
  categoryId: string;
  categoryName: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string | null;
  ingredients: string[];
  allergens: Allergen[];
  allergenInfoComplete: boolean; // если false — AI обязан предупредить, что данные неполные
  tags: DishTag[];
  spiceLevel: 0 | 1 | 2 | 3; // 0 — не острое, 3 — очень острое
  isAvailable: boolean;
}

export interface AISettings {
  restaurantId: string;
  greeting: string;
  tone: 'friendly' | 'professional' | 'playful';
  upsellEnabled: boolean;
  systemPromptExtra: string;
}

// Ответы гостя из опроса
export interface GuestPreferences {
  craving: 'meat' | 'fish' | 'pasta' | 'light' | 'any';
  hungerLevel: 'light' | 'medium' | 'high';
  spice: 'mild' | 'medium' | 'hot' | 'any';
  budget: 'under3000' | '3000-6000' | '6000-10000' | 'any';
  excludedIngredients: string; // свободный текст
  allergies: Allergen[];
}

export interface DishRecommendation {
  dish: Dish;
  matchScore: number; // 0-100
  reason: string;
  allergenWarning: string | null;
}

export interface RecommendationResult {
  recommendations: DishRecommendation[];
  upsell: {
    dish: Dish;
    message: string;
  } | null;
  noGoodMatch: boolean;
  note: string | null; // напр. "точных совпадений мало, вот ближайшие варианты"
}

// --- Чат-виджет (свободный диалог с AI-помощником) ---

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  isVoice?: boolean;
}
