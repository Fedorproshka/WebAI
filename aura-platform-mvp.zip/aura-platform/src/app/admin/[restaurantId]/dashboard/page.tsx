import { getRestaurantById } from '@/lib/repository';
import { getDashboardStats } from '@/lib/analytics';
import { notFound } from 'next/navigation';
import DashboardStatsView from '@/components/admin/DashboardStats';
import QRCodeGenerator from '@/components/admin/QRCodeGenerator';

export default async function DashboardPage({ params }: { params: { restaurantId: string } }) {
  const restaurant = await getRestaurantById(params.restaurantId);
  if (!restaurant) notFound();
  const stats = await getDashboardStats(params.restaurantId);

  return (
    <div>
      <h1 className="font-display italic text-3xl mb-8">Dashboard</h1>
      <DashboardStatsView stats={stats} />
      <div className="mt-8 max-w-md">
        <QRCodeGenerator slug={restaurant.slug} />
      </div>
    </div>
  );
}
