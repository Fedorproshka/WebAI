import { supabaseServer, isSupabaseConfiguredServer } from '@/lib/supabase/server';
import { AURA_AI_SETTINGS, AURA_DISHES, AURA_RESTAURANT } from '@/data/mockRestaurant';
import { AISettings, Dish, Restaurant } from '@/lib/types';

/**
 * Единая точка доступа к данным ресторана.
 *
 * ПРАВИЛО ИЗОЛЯЦИИ: каждая функция принимает restaurantId/slug и ВСЕГДА
 * фильтрует по нему на уровне запроса (а не на уровне приложения после
 * получения "всех" данных). В реальной БД это дублируется политиками RLS
 * (см. supabase/schema.sql), так что даже ошибка в коде не приведёт к утечке
 * данных одного ресторана в другой.
 *
 * Если Supabase не настроен (нет env-переменных) — работаем в DEMO-режиме на
 * тестовых данных ресторана AURA, чтобы проект можно было запустить и
 * протестировать сразу после `npm install`.
 */

export async function getRestaurantBySlug(slug: string): Promise<Restaurant | null> {
  if (!isSupabaseConfiguredServer || !supabaseServer) {
    return slug === AURA_RESTAURANT.slug ? AURA_RESTAURANT : null;
  }
  const { data, error } = await supabaseServer
    .from('restaurants')
    .select('*')
    .eq('slug', slug)
    .single();
  if (error || !data) return null;
  return mapRestaurant(data);
}

export async function getRestaurantById(id: string): Promise<Restaurant | null> {
  if (!isSupabaseConfiguredServer || !supabaseServer) {
    return id === AURA_RESTAURANT.id ? AURA_RESTAURANT : null;
  }
  const { data, error } = await supabaseServer
    .from('restaurants')
    .select('*')
    .eq('id', id)
    .single();
  if (error || !data) return null;
  return mapRestaurant(data);
}

export async function getDishesByRestaurant(restaurantId: string): Promise<Dish[]> {
  if (!isSupabaseConfiguredServer || !supabaseServer) {
    return restaurantId === AURA_RESTAURANT.id ? AURA_DISHES : [];
  }
  const { data, error } = await supabaseServer
    .from('dishes')
    .select('*, categories(name)')
    .eq('restaurant_id', restaurantId); // ключевой фильтр изоляции
  if (error || !data) return [];
  return data.map(mapDish);
}

export async function getAISettings(restaurantId: string): Promise<AISettings> {
  if (!isSupabaseConfiguredServer || !supabaseServer) {
    return restaurantId === AURA_RESTAURANT.id
      ? AURA_AI_SETTINGS
      : { ...AURA_AI_SETTINGS, restaurantId };
  }
  const { data } = await supabaseServer
    .from('ai_settings')
    .select('*')
    .eq('restaurant_id', restaurantId)
    .single();
  if (!data) return { ...AURA_AI_SETTINGS, restaurantId };
  return mapAISettings(data);
}

export async function upsertDish(dish: Dish): Promise<{ ok: boolean; error?: string }> {
  if (!isSupabaseConfiguredServer || !supabaseServer) {
    return { ok: false, error: 'DEMO_MODE_READONLY' };
  }
  const { error } = await supabaseServer.from('dishes').upsert({
    id: dish.id,
    restaurant_id: dish.restaurantId, // никогда не берём из клиента без проверки сессии админа
    category_id: dish.categoryId,
    name: dish.name,
    description: dish.description,
    price: dish.price,
    image_url: dish.imageUrl,
    ingredients: dish.ingredients,
    allergens: dish.allergens,
    allergen_info_complete: dish.allergenInfoComplete,
    tags: dish.tags,
    spice_level: dish.spiceLevel,
    is_available: dish.isAvailable,
  });
  if (error) return { ok: false, error: error.message };
  return { ok: true };
}

export async function deleteDish(restaurantId: string, dishId: string) {
  if (!isSupabaseConfiguredServer || !supabaseServer) {
    return { ok: false, error: 'DEMO_MODE_READONLY' };
  }
  const { error } = await supabaseServer
    .from('dishes')
    .delete()
    .eq('id', dishId)
    .eq('restaurant_id', restaurantId); // двойная проверка изоляции при удалении
  if (error) return { ok: false, error: error.message };
  return { ok: true };
}

export async function logAnalyticsEvent(
  restaurantId: string,
  type: string,
  payload: Record<string, unknown>,
) {
  if (!isSupabaseConfiguredServer || !supabaseServer) return; // в demo не логируем
  await supabaseServer.from('analytics_events').insert({
    restaurant_id: restaurantId,
    type,
    payload,
  });
}

// --- маппинг snake_case (БД) -> camelCase (приложение) ---

function mapRestaurant(row: any): Restaurant {
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    description: row.description ?? '',
    logoUrl: row.logo_url,
    currency: row.currency ?? '₸',
    createdAt: row.created_at,
  };
}

function mapDish(row: any): Dish {
  return {
    id: row.id,
    restaurantId: row.restaurant_id,
    categoryId: row.category_id,
    categoryName: row.categories?.name ?? '',
    name: row.name,
    description: row.description ?? '',
    price: row.price,
    imageUrl: row.image_url,
    ingredients: row.ingredients ?? [],
    allergens: row.allergens ?? [],
    allergenInfoComplete: row.allergen_info_complete ?? true,
    tags: row.tags ?? [],
    spiceLevel: row.spice_level ?? 0,
    isAvailable: row.is_available ?? true,
  };
}

function mapAISettings(row: any): AISettings {
  return {
    restaurantId: row.restaurant_id,
    greeting: row.greeting,
    tone: row.tone,
    upsellEnabled: row.upsell_enabled,
    systemPromptExtra: row.system_prompt_extra ?? '',
  };
}
