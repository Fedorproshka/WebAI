'use client';

import { useState } from 'react';
import { AISettings } from '@/lib/types';

export default function AISettingsForm({ initial }: { initial: AISettings }) {
  const [greeting, setGreeting] = useState(initial.greeting);
  const [tone, setTone] = useState(initial.tone);
  const [upsellEnabled, setUpsellEnabled] = useState(initial.upsellEnabled);
  const [systemPromptExtra, setSystemPromptExtra] = useState(initial.systemPromptExtra);
  const [saved, setSaved] = useState(false);
  const [note, setNote] = useState<string | null>(null);

  async function handleSave() {
    // Для MVP настройки AI сохраняются так же через /api/dishes-подобный
    // эндпоинт в реальной реализации; здесь — заглушка, показывающая, что
    // без Supabase изменения не персистятся между перезапусками.
    setSaved(true);
    setNote('В demo-режиме без Supabase настройки не сохраняются между перезагрузками страницы.');
    setTimeout(() => setSaved(false), 2000);
  }

  return (
    <div className="max-w-xl space-y-6">
      <div>
        <label className="block text-xs text-espresso-900/60 mb-1">Приветствие на главном экране гостя</label>
        <textarea value={greeting} onChange={(e) => setGreeting(e.target.value)} rows={3} className="w-full rounded-xl border border-espresso-900/15 px-4 py-2.5 outline-none focus:border-brass-500 resize-none" />
      </div>

      <div>
        <label className="block text-xs text-espresso-900/60 mb-2">Стиль общения AI</label>
        <div className="flex gap-2">
          {(['friendly', 'professional', 'playful'] as const).map((t) => (
            <button key={t} onClick={() => setTone(t)}
              className={`px-4 py-2 rounded-full text-sm border ${tone === t ? 'bg-brass-500/15 border-brass-500 text-brass-600' : 'border-espresso-900/15 text-espresso-900/60'}`}>
              {t === 'friendly' ? 'Дружелюбный' : t === 'professional' ? 'Профессиональный' : 'Игривый'}
            </button>
          ))}
        </div>
      </div>

      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={upsellEnabled} onChange={(e) => setUpsellEnabled(e.target.checked)} />
        Включить ненавязчивые дополнительные рекомендации (допродажа)
      </label>

      <div>
        <label className="block text-xs text-espresso-900/60 mb-1">Доп. инструкции для AI (необязательно)</label>
        <textarea value={systemPromptExtra} onChange={(e) => setSystemPromptExtra(e.target.value)} rows={2}
          placeholder="Например: делай акцент на сезонных блюдах"
          className="w-full rounded-xl border border-espresso-900/15 px-4 py-2.5 outline-none focus:border-brass-500 resize-none" />
      </div>

      <button onClick={handleSave} className="px-8 py-3 rounded-full bg-brass-500 text-espresso-950 font-medium hover:bg-brass-400 transition-colors">
        {saved ? 'Сохранено ✓' : 'Сохранить настройки'}
      </button>
      {note && <p className="text-xs text-espresso-900/40">{note}</p>}
    </div>
  );
}
