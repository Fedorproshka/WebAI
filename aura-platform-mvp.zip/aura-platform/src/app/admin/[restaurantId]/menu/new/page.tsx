import DishForm from '@/components/admin/DishForm';

export default function NewDishPage({ params }: { params: { restaurantId: string } }) {
  return (
    <div>
      <h1 className="font-display italic text-3xl mb-8">Новое блюдо</h1>
      <DishForm restaurantId={params.restaurantId} />
    </div>
  );
}
