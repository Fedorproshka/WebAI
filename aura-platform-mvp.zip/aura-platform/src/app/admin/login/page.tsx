'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

// ВНИМАНИЕ: это упрощённый demo-вход для MVP (Этап 1). В реальной версии
// здесь должен быть Supabase Auth (email+password или magic link), после
// которого restaurantId берётся из сессии, а не вводится вручную.
// Для теста используйте restaurantId демо-ресторана: aura-restaurant

export default function AdminLoginPage() {
  const router = useRouter();
  const [restaurantId, setRestaurantId] = useState('aura-restaurant');

  return (
    <div className="min-h-screen flex items-center justify-center bg-espresso-950 px-6">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          router.push(`/admin/${restaurantId}/dashboard`);
        }}
        className="w-full max-w-sm bg-espresso-800/60 border border-parchment-200/10 rounded-2xl p-8"
      >
        <h1 className="font-display italic text-2xl text-parchment-50 mb-2">Кабинет ресторана</h1>
        <p className="text-sm text-parchment-200/50 mb-6">
          Demo-режим MVP. Введите ID ресторана.
        </p>
        <label className="block text-xs text-parchment-200/60 mb-2">ID ресторана</label>
        <input
          value={restaurantId}
          onChange={(e) => setRestaurantId(e.target.value)}
          className="w-full rounded-xl bg-espresso-900 border border-parchment-200/10 px-4 py-3 text-parchment-100 mb-6 outline-none focus:border-brass-400/50"
        />
        <button
          type="submit"
          className="w-full py-3 rounded-full bg-brass-500 text-espresso-950 font-medium hover:bg-brass-400 transition-colors"
        >
          Войти
        </button>
      </form>
    </div>
  );
}
