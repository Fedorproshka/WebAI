'use client';

import { Restaurant, AISettings } from '@/lib/types';

interface Props {
  restaurant: Restaurant;
  aiSettings: AISettings;
  onStart: () => void;
}

export default function WelcomeScreen({ restaurant, aiSettings, onStart }: Props) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 py-16 text-center animate-fadeUp">
      <div className="w-16 h-16 rounded-full border border-brass-500/40 flex items-center justify-center mb-8">
        <span className="font-display italic text-2xl text-brass-400">
          {restaurant.name.charAt(0)}
        </span>
      </div>

      <span className="text-brass-400 tracking-[0.25em] text-xs uppercase mb-4">
        {restaurant.name}
      </span>

      <h1 className="font-display text-3xl md:text-5xl italic text-parchment-50 max-w-lg text-balance leading-tight">
        Не знаете, что выбрать?
      </h1>

      <p className="mt-5 max-w-md text-parchment-200/70 text-base md:text-lg">
        {aiSettings.greeting}
      </p>

      <button
        onClick={onStart}
        className="mt-10 px-10 py-4 rounded-full bg-brass-500 text-espresso-950 font-medium text-lg
                   hover:bg-brass-400 active:scale-[0.98] transition-all shadow-[0_8px_30px_-8px_rgba(201,162,39,0.5)]"
      >
        Подобрать блюдо
      </button>

      <p className="mt-6 text-xs text-parchment-200/40">Займёт около минуты</p>
    </div>
  );
}
