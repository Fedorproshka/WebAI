const FEATURES = [
  { title: 'Свежие ингредиенты', desc: 'Только качественные продукты' },
  { title: 'Опытные повара', desc: 'Профессионалы своего дела' },
  { title: 'Быстрая подача', desc: 'Ваш заказ будет готов вовремя' },
  { title: 'Сделано с любовью', desc: 'Мы готовим для вас с душой' },
];

export default function FeaturesRow() {
  return (
    <section id="about" className="max-w-7xl mx-auto px-6 lg:px-10 py-14 border-t border-forest-900/8">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {FEATURES.map((f) => (
          <div key={f.title}>
            <div className="w-10 h-10 rounded-full bg-forest-700/10 flex items-center justify-center mb-3">
              <span className="w-2 h-2 rounded-full bg-forest-700" />
            </div>
            <p className="font-medium text-forest-900">{f.title}</p>
            <p className="text-sm text-forest-900/50 mt-1">{f.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
