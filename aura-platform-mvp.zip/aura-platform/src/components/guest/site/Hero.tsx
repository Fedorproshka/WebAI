'use client';

import Image from 'next/image';
import { Dish, Restaurant } from '@/lib/types';

export default function Hero({ restaurant, heroDish }: { restaurant: Restaurant; heroDish?: Dish }) {
  return (
    <section className="max-w-7xl mx-auto px-6 lg:px-10 pt-12 lg:pt-16 pb-10">
      <div className="grid lg:grid-cols-[1fr_1.1fr] gap-10 items-center">
        <div>
          <h1 className="font-display italic text-4xl md:text-5xl lg:text-[3.4rem] text-forest-900 leading-[1.08] text-balance">
            Вкус, созданный для вас
          </h1>
          <p className="mt-5 text-forest-900/60 text-lg max-w-md">
            Откройте для себя блюда, приготовленные из свежих ингредиентов с
            любовью к деталям — и AI-помощник, который подскажет, что выбрать.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <a
              href="#menu"
              className="px-7 py-3.5 rounded-full bg-forest-700 text-parchment-50 font-medium hover:bg-forest-900 transition-colors inline-flex items-center gap-2"
            >
              Смотреть меню
              <span aria-hidden>↓</span>
            </a>
            <a
              href={`/r/${restaurant.slug}/survey`}
              className="px-7 py-3.5 rounded-full border border-forest-900/15 text-forest-900 font-medium hover:border-forest-700/50 transition-colors"
            >
              Пройти AI-подбор блюда
            </a>
          </div>
        </div>

        <div className="relative h-64 sm:h-80 lg:h-[26rem] rounded-xl2 overflow-hidden bg-forest-900/5">
          {heroDish?.imageUrl && (
            <Image src={heroDish.imageUrl} alt={heroDish.name} fill className="object-cover" unoptimized priority />
          )}
        </div>
      </div>
    </section>
  );
}
