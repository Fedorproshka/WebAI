import { NextRequest, NextResponse } from 'next/server';
import { synthesizeSpeech } from '@/lib/ai/voice';

export const runtime = 'nodejs';

// POST /api/voice/speak { text } -> audio/mpeg stream
export async function POST(req: NextRequest) {
  try {
    const { text } = (await req.json()) as { text: string };
    if (!text || text.trim().length === 0) {
      return NextResponse.json({ error: 'text обязателен' }, { status: 400 });
    }
    if (text.length > 2000) {
      return NextResponse.json({ error: 'Текст слишком длинный для озвучки' }, { status: 400 });
    }

    const result = await synthesizeSpeech(text);
    if (!result) {
      return NextResponse.json(
        { error: 'ELEVENLABS_API_KEY не настроен — озвучка недоступна в demo-режиме.' },
        { status: 501 },
      );
    }

    return new NextResponse(result.audio, {
      headers: {
        'Content-Type': result.contentType,
        'Cache-Control': 'no-store',
      },
    });
  } catch (err) {
    console.error('voice/speak API error', err);
    return NextResponse.json({ error: 'Внутренняя ошибка сервера' }, { status: 500 });
  }
}
