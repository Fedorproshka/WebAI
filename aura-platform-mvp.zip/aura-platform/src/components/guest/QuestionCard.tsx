'use client';

interface Option {
  value: string;
  label: string;
}

interface Props {
  step: number;
  totalSteps: number;
  question: string;
  options: Option[];
  onSelect: (value: string) => void;
  onBack?: () => void;
}

export default function QuestionCard({ step, totalSteps, question, options, onSelect, onBack }: Props) {
  return (
    <div className="min-h-screen flex flex-col justify-center px-6 py-12 animate-fadeUp">
      <div className="max-w-md w-full mx-auto">
        <div className="flex items-center gap-2 mb-8">
          {Array.from({ length: totalSteps }).map((_, i) => (
            <div
              key={i}
              className={`h-1 flex-1 rounded-full transition-colors ${
                i < step ? 'bg-brass-500' : 'bg-parchment-200/10'
              }`}
            />
          ))}
        </div>

        <p className="text-xs text-parchment-200/50 mb-2">
          Вопрос {step} из {totalSteps}
        </p>
        <h2 className="font-display text-2xl md:text-3xl italic text-parchment-50 mb-8 text-balance">
          {question}
        </h2>

        <div className="grid gap-3">
          {options.map((opt) => (
            <button
              key={opt.value}
              onClick={() => onSelect(opt.value)}
              className="w-full text-left px-6 py-4 rounded-2xl border border-parchment-200/10 bg-espresso-800/60
                         hover:border-brass-400/50 hover:bg-espresso-700/60 transition-colors text-parchment-100"
            >
              {opt.label}
            </button>
          ))}
        </div>

        {onBack && (
          <button
            onClick={onBack}
            className="mt-8 text-sm text-parchment-200/50 hover:text-parchment-100 transition-colors"
          >
            ← Назад
          </button>
        )}
      </div>
    </div>
  );
}
