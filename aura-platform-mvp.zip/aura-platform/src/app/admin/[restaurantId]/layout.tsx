import Link from 'next/link';
import { getRestaurantById } from '@/lib/repository';
import { notFound } from 'next/navigation';

export default async function AdminLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { restaurantId: string };
}) {
  const restaurant = await getRestaurantById(params.restaurantId);
  if (!restaurant) notFound();

  const base = `/admin/${params.restaurantId}`;

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-parchment-50 text-espresso-900">
      <aside className="md:w-64 shrink-0 border-b md:border-b-0 md:border-r border-espresso-900/10 bg-espresso-950 text-parchment-100 p-6 flex md:flex-col gap-6 md:gap-10">
        <div>
          <p className="text-xs uppercase tracking-widest text-brass-400">Кабинет ресторана</p>
          <p className="font-display italic text-xl mt-1">{restaurant.name}</p>
        </div>
        <nav className="flex md:flex-col gap-1 text-sm">
          <Link href={`${base}/dashboard`} className="px-3 py-2 rounded-lg hover:bg-espresso-800 transition-colors">
            Dashboard
          </Link>
          <Link href={`${base}/menu`} className="px-3 py-2 rounded-lg hover:bg-espresso-800 transition-colors">
            Меню
          </Link>
          <Link href={`${base}/ai-settings`} className="px-3 py-2 rounded-lg hover:bg-espresso-800 transition-colors">
            AI
          </Link>
          <Link href={`/r/${restaurant.slug}`} className="px-3 py-2 rounded-lg hover:bg-espresso-800 transition-colors mt-auto opacity-70">
            Открыть страницу гостя ↗
          </Link>
        </nav>
      </aside>
      <main className="flex-1 p-6 md:p-10">{children}</main>
    </div>
  );
}
