import Link from 'next/link';

export default function PlatformHome() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-6 text-center">
      <span className="text-brass-400 tracking-[0.3em] text-xs uppercase mb-6">
        AI-платформа для ресторанов
      </span>
      <h1 className="font-display text-4xl md:text-6xl italic text-parchment-50 max-w-3xl text-balance">
        Каждый гость получает своего личного метрдотеля
      </h1>
      <p className="mt-6 max-w-xl text-parchment-200/70 text-lg">
        Подключите ваш ресторан, загрузите меню — и AI будет подбирать блюда
        под вкус, бюджет и ограничения каждого гостя.
      </p>
      <div className="mt-10 flex flex-col sm:flex-row gap-4">
        <Link
          href="/r/aura"
          className="px-8 py-3 rounded-full bg-brass-500 text-espresso-950 font-medium hover:bg-brass-400 transition-colors"
        >
          Посмотреть демо-ресторан AURA
        </Link>
        <Link
          href="/admin/login"
          className="px-8 py-3 rounded-full border border-parchment-200/20 text-parchment-100 hover:border-brass-400/60 transition-colors"
        >
          Войти в кабинет ресторана
        </Link>
      </div>
    </main>
  );
}
