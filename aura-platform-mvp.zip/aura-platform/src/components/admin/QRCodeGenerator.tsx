'use client';

import { useState } from 'react';
import { QRCodeCanvas } from 'qrcode.react';

export default function QRCodeGenerator({ slug }: { slug: string }) {
  const [show, setShow] = useState(false);
  const [origin, setOrigin] = useState('');

  const url = `${origin || 'https://your-domain.com'}/r/${slug}`;

  return (
    <div className="rounded-2xl bg-white border border-espresso-900/10 p-6">
      <h3 className="font-display italic text-lg mb-2">QR-код для гостей</h3>
      <p className="text-sm text-espresso-900/50 mb-4 break-all">{url}</p>
      <button
        onClick={() => {
          setOrigin(window.location.origin);
          setShow(true);
        }}
        className="px-6 py-2.5 rounded-full bg-espresso-950 text-parchment-50 text-sm hover:bg-espresso-800 transition-colors"
      >
        Создать QR-код
      </button>
      {show && (
        <div className="mt-6 flex justify-center">
          <div className="p-4 bg-white rounded-xl border border-espresso-900/10">
            <QRCodeCanvas value={`${window.location.origin}/r/${slug}`} size={180} />
          </div>
        </div>
      )}
    </div>
  );
}
