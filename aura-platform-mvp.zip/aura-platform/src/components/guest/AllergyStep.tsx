'use client';

import { useState } from 'react';
import { Allergen } from '@/lib/types';

const ALLERGEN_OPTIONS: { value: Allergen; label: string }[] = [
  { value: 'gluten', label: 'Глютен' },
  { value: 'dairy', label: 'Молочное' },
  { value: 'eggs', label: 'Яйца' },
  { value: 'nuts', label: 'Орехи' },
  { value: 'peanuts', label: 'Арахис' },
  { value: 'fish', label: 'Рыба' },
  { value: 'shellfish', label: 'Морепродукты' },
  { value: 'soy', label: 'Соя' },
  { value: 'sesame', label: 'Кунжут' },
];

interface Props {
  step: number;
  totalSteps: number;
  onSubmit: (excludedIngredients: string, allergies: Allergen[]) => void;
  onBack: () => void;
}

export default function AllergyStep({ step, totalSteps, onSubmit, onBack }: Props) {
  const [text, setText] = useState('');
  const [allergies, setAllergies] = useState<Allergen[]>([]);

  const toggle = (a: Allergen) => {
    setAllergies((prev) => (prev.includes(a) ? prev.filter((x) => x !== a) : [...prev, a]));
  };

  return (
    <div className="min-h-screen flex flex-col justify-center px-6 py-12 animate-fadeUp">
      <div className="max-w-md w-full mx-auto">
        <div className="flex items-center gap-2 mb-8">
          {Array.from({ length: totalSteps }).map((_, i) => (
            <div
              key={i}
              className={`h-1 flex-1 rounded-full transition-colors ${
                i < step ? 'bg-brass-500' : 'bg-parchment-200/10'
              }`}
            />
          ))}
        </div>

        <p className="text-xs text-parchment-200/50 mb-2">
          Вопрос {step} из {totalSteps}
        </p>
        <h2 className="font-display text-2xl md:text-3xl italic text-parchment-50 mb-2 text-balance">
          Есть продукты, которые вы не едите?
        </h2>
        <p className="text-sm text-parchment-200/50 mb-4">Необязательно — можно пропустить</p>

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Например: не ем кинзу, лук"
          rows={2}
          className="w-full rounded-2xl bg-espresso-800/60 border border-parchment-200/10 px-5 py-4
                     text-parchment-100 placeholder:text-parchment-200/30 focus:border-brass-400/50 outline-none resize-none"
        />

        <p className="text-sm text-parchment-200/70 mt-6 mb-3">Аллергии (если есть):</p>
        <div className="flex flex-wrap gap-2">
          {ALLERGEN_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              onClick={() => toggle(opt.value)}
              className={`px-4 py-2 rounded-full text-sm border transition-colors ${
                allergies.includes(opt.value)
                  ? 'bg-clay-500/20 border-clay-500 text-parchment-50'
                  : 'border-parchment-200/15 text-parchment-200/60 hover:border-parchment-200/30'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-4 mt-8">
          <button
            onClick={onBack}
            className="text-sm text-parchment-200/50 hover:text-parchment-100 transition-colors"
          >
            ← Назад
          </button>
          <button
            onClick={() => onSubmit(text, allergies)}
            className="ml-auto px-8 py-3 rounded-full bg-brass-500 text-espresso-950 font-medium
                       hover:bg-brass-400 active:scale-[0.98] transition-all"
          >
            Показать рекомендации
          </button>
        </div>
      </div>
    </div>
  );
}
