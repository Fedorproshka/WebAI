import { Dish, GuestPreferences, RecommendationResult } from '@/lib/types';

/**
 * Rule-based рекомендатель — работает БЕЗ Gemini API key, чтобы демо/MVP
 * можно было проверить сразу. Как только в .env.local появится GEMINI_API_KEY,
 * recommend.ts автоматически переключится на настоящий AI (см. recommend.ts).
 *
 * Логика намеренно простая и прозрачная: считаем очки соответствия по каждому
 * критерию, отсекаем аллергены/исключения жёстко (не "мягко").
 */
export function fallbackRecommend(
  shortlist: Dish[],
  preferences: GuestPreferences,
  upsellEnabled: boolean,
): RecommendationResult {
  const excluded = preferences.excludedIngredients
    .toLowerCase()
    .split(/[,;\n]/)
    .map((s) => s.trim())
    .filter(Boolean);

  const safe = shortlist.filter((dish) => {
    const hasAllergen = dish.allergens.some((a) => preferences.allergies.includes(a));
    if (hasAllergen) return false;
    const hasExcluded = excluded.some((ex) =>
      dish.ingredients.some((ing) => ing.toLowerCase().includes(ex)),
    );
    return !hasExcluded;
  });

  const pool = safe.length > 0 ? safe : shortlist;

  const scored = pool.map((dish) => {
    let score = 40;
    const reasons: string[] = [];

    if (preferences.craving !== 'any' && dish.tags.includes(preferences.craving as any)) {
      score += 25;
      reasons.push(`вы выбрали "${cravingLabel(preferences.craving)}"`);
    }
    if (preferences.spice !== 'any') {
      const wantLevel = spiceToLevel(preferences.spice);
      if (dish.spiceLevel === wantLevel) {
        score += 15;
        reasons.push('уровень остроты совпадает с вашими предпочтениями');
      } else if (Math.abs(dish.spiceLevel - wantLevel) === 1) {
        score += 5;
      }
    }
    const budgetMax = budgetToMax(preferences.budget);
    if (budgetMax === null || dish.price <= budgetMax) {
      score += 15;
      if (budgetMax !== null) reasons.push('цена вписывается в ваш бюджет');
    } else {
      score -= 30;
    }
    if (preferences.hungerLevel === 'high' && dish.price >= 4000) score += 5;
    if (preferences.hungerLevel === 'light' && dish.tags.includes('light')) score += 10;

    score = Math.max(5, Math.min(98, score));

    const reason = reasons.length
      ? `Рекомендую «${dish.name}», потому что ${reasons.join(' и ')}.`
      : `«${dish.name}» — хороший сбалансированный вариант из меню под ваш запрос.`;

    const allergenWarning = !dish.allergenInfoComplete
      ? 'Информация об аллергенах для этого блюда может быть неполной — пожалуйста, уточните у персонала.'
      : null;

    return { dish, matchScore: score, reason, allergenWarning };
  });

  scored.sort((a, b) => b.matchScore - a.matchScore);
  const top = scored.slice(0, 3);

  let upsell: RecommendationResult['upsell'] = null;
  if (upsellEnabled && top.length > 0) {
    const main = top[0].dish;
    const candidate = shortlist.find(
      (d) =>
        d.id !== main.id &&
        ((main.tags.includes('meat') && d.tags.includes('drink')) ||
          (preferences.hungerLevel === 'high' && d.tags.includes('dessert'))),
    );
    if (candidate) {
      upsell = {
        dish: candidate,
        message: candidate.tags.includes('dessert')
          ? `Если хотите полноценный ужин, могу предложить десерт «${candidate.name}».`
          : `К этому блюду хорошо подойдёт «${candidate.name}».`,
      };
    }
  }

  return {
    recommendations: top,
    upsell,
    noGoodMatch: safe.length === 0,
    note: safe.length === 0 ? 'Точных совпадений не нашлось, вот ближайшие варианты из меню.' : null,
  };
}

function cravingLabel(c: string) {
  const map: Record<string, string> = {
    meat: 'мясное блюдо',
    fish: 'рыбное блюдо',
    pasta: 'пасту',
    light: 'что-то лёгкое',
  };
  return map[c] ?? c;
}

function spiceToLevel(s: string): number {
  return { mild: 0, medium: 1, hot: 3 }[s] ?? 0;
}

function budgetToMax(b: string): number | null {
  return (
    {
      under3000: 3000,
      '3000-6000': 6000,
      '6000-10000': 10000,
      any: null,
    } as Record<string, number | null>
  )[b] ?? null;
}
