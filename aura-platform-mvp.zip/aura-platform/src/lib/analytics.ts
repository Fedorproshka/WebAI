import { supabaseServer, isSupabaseConfiguredServer } from '@/lib/supabase/server';
import { getDishesByRestaurant } from '@/lib/repository';

export interface DashboardStats {
  dishCount: number;
  recommendationCount: number;
  topDishes: { name: string; count: number }[];
  topCategories: { name: string; count: number }[];
  guestSessionsCount: number;
  isLiveData: boolean; // false = demo-режим, показываем "нет данных" честно
}

export async function getDashboardStats(restaurantId: string): Promise<DashboardStats> {
  const dishes = await getDishesByRestaurant(restaurantId);

  if (!isSupabaseConfiguredServer || !supabaseServer) {
    // Demo-режим: реальной аналитики ещё нет (события не логируются без БД).
    // Честно показываем это администратору, а не выдумываем цифры.
    return {
      dishCount: dishes.length,
      recommendationCount: 0,
      topDishes: [],
      topCategories: [],
      guestSessionsCount: 0,
      isLiveData: false,
    };
  }

  const { data: events } = await supabaseServer
    .from('analytics_events')
    .select('*')
    .eq('restaurant_id', restaurantId)
    .eq('type', 'recommendation_generated');

  const dishCounts = new Map<string, number>();
  const categoryCounts = new Map<string, number>();
  const dishById = new Map(dishes.map((d) => [d.id, d]));

  (events ?? []).forEach((ev: any) => {
    const dishIds: string[] = ev.payload?.dishIds ?? [];
    dishIds.forEach((id) => {
      dishCounts.set(id, (dishCounts.get(id) ?? 0) + 1);
      const dish = dishById.get(id);
      if (dish) categoryCounts.set(dish.categoryName, (categoryCounts.get(dish.categoryName) ?? 0) + 1);
    });
  });

  const topDishes = [...dishCounts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([id, count]) => ({ name: dishById.get(id)?.name ?? id, count }));

  const topCategories = [...categoryCounts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([name, count]) => ({ name, count }));

  return {
    dishCount: dishes.length,
    recommendationCount: events?.length ?? 0,
    topDishes,
    topCategories,
    guestSessionsCount: events?.length ?? 0,
    isLiveData: true,
  };
}
