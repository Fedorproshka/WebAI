import { AISettings, Dish, GuestPreferences } from '@/lib/types';

/**
 * Строит промпт для Gemini.
 *
 * ВАЖНО (п.11 ТЗ): в промпт передаётся ТОЛЬКО отфильтрованный шорт-лист блюд
 * (см. shortlistDishes в recommend.ts), а не всё меню — это и экономит
 * токены, и снижает риск того, что модель "перепутает" блюда разных
 * категорий бюджета.
 */
export function buildRecommendationPrompt(params: {
  restaurantName: string;
  aiSettings: AISettings;
  preferences: GuestPreferences;
  shortlist: Dish[];
}): string {
  const { restaurantName, aiSettings, preferences, shortlist } = params;

  const toneInstruction =
    aiSettings.tone === 'professional'
      ? 'Пиши сдержанно и профессионально, как метрдотель high-end ресторана.'
      : aiSettings.tone === 'playful'
        ? 'Пиши легко, дружелюбно и с лёгкой игривостью, но без излишней фамильярности.'
        : 'Пиши тепло, дружелюбно и по-человечески, как внимательный официант.';

  const dishesJson = shortlist.map((d) => ({
    id: d.id,
    name: d.name,
    description: d.description,
    price: d.price,
    ingredients: d.ingredients,
    allergens: d.allergens,
    allergenInfoComplete: d.allergenInfoComplete,
    tags: d.tags,
    spiceLevel: d.spiceLevel,
    category: d.categoryName,
  }));

  return `Ты — AI-помощник ресторана "${restaurantName}". Твоя задача — порекомендовать гостю блюда ТОЛЬКО из списка ниже.

СТРОГИЕ ПРАВИЛА (нарушать нельзя):
1. Используй ТОЛЬКО блюда, ингредиенты, цены и характеристики из переданного JSON. НИЧЕГО не придумывай и не добавляй.
2. Если у блюда allergenInfoComplete=false — ОБЯЗАТЕЛЬНО включи предупреждение allergenWarning вида "Информация об аллергенах может быть неполной, уточните у персонала", даже если явных аллергенов не указано.
3. Если у гостя указаны аллергии (allergies) и они пересекаются с allergens блюда — такое блюдо вообще НЕ рекомендуй.
4. Если исключённые продукты гостя (excludedIngredients, свободный текст) явно совпадают с ingredients блюда — не рекомендуй это блюдо.
5. Если совсем нет хорошо подходящих блюд — верни noGoodMatch=true, укажи note и всё равно предложи 1-3 ближайших по духу варианта из списка (честно, без натяжек в reason).
6. Верни РОВНО валидный JSON без markdown-разметки, без \`\`\`, без пояснений вне JSON.
7. ${toneInstruction}
8. Поле reason пиши от лица AI, коротко (1-2 предложения), объясняя связь с конкретными ответами гостя.
9. upsell предлагай, только если upsellEnabled=true И дополнение реально уместно (например лёгкий напиток к сытному блюду, десерт если гость "очень голоден"). Если неуместно — верни upsell: null.

Настройки ресторана:
- upsellEnabled: ${aiSettings.upsellEnabled}
${aiSettings.systemPromptExtra ? `- Доп. инструкции ресторана: ${aiSettings.systemPromptExtra}` : ''}

Предпочтения гостя:
${JSON.stringify(preferences, null, 2)}

Доступные блюда (шорт-лист, уже отфильтрованный по бюджету/категории):
${JSON.stringify(dishesJson, null, 2)}

Верни JSON строго в такой форме:
{
  "recommendations": [
    { "dishId": "...", "matchScore": 0-100, "reason": "...", "allergenWarning": "строка или null" }
  ],
  "upsell": { "dishId": "...", "message": "..." } | null,
  "noGoodMatch": true|false,
  "note": "строка или null"
}

Верни от 1 до 3 объектов в recommendations, отсортированных по matchScore по убыванию.`;
}
