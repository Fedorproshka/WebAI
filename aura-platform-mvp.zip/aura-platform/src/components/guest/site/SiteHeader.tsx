'use client';

import Link from 'next/link';
import { Restaurant } from '@/lib/types';

export default function SiteHeader({ restaurant }: { restaurant: Restaurant }) {
  return (
    <header className="sticky top-0 z-30 bg-parchment-50/90 backdrop-blur border-b border-forest-900/8">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 h-20 flex items-center justify-between gap-6">
        <Link href="#" className="flex items-center gap-3 shrink-0">
          <span className="w-9 h-9 rounded-full bg-forest-700 flex items-center justify-center">
            <span className="font-display italic text-parchment-50 text-sm">
              {restaurant.name.charAt(0)}
            </span>
          </span>
          <span className="leading-tight">
            <span className="block font-display italic text-lg text-forest-900">{restaurant.name}</span>
            <span className="block text-[10px] tracking-[0.2em] uppercase text-forest-900/50">Restaurant</span>
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-8 text-sm text-forest-900/70">
          <a href="#" className="hover:text-forest-900 transition-colors">Главная</a>
          <a href="#menu" className="text-forest-900 font-medium border-b-2 border-forest-600 pb-1">Меню</a>
          <a href="#about" className="hover:text-forest-900 transition-colors">О ресторане</a>
          <a href="#contacts" className="hover:text-forest-900 transition-colors">Контакты</a>
        </nav>

        <div className="flex items-center gap-4 shrink-0">
          <button className="hidden sm:flex items-center gap-1 text-sm text-forest-900/60 hover:text-forest-900">
            RU
          </button>
          <button className="px-5 py-2.5 rounded-full bg-forest-700 text-parchment-50 text-sm font-medium hover:bg-forest-900 transition-colors whitespace-nowrap">
            Забронировать столик
          </button>
        </div>
      </div>
    </header>
  );
}
