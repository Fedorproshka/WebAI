'use client';

import { ChatMessage } from '@/lib/types';

export default function ChatMessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === 'user';
  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
          isUser
            ? 'bg-forest-700 text-parchment-50 rounded-br-sm'
            : 'bg-forest-900/5 text-forest-900 rounded-bl-sm'
        }`}
      >
        {message.isVoice && (
          <span className="flex items-center gap-1 text-[10px] uppercase tracking-wide opacity-60 mb-1">
            🎙 голосом
          </span>
        )}
        {message.text}
      </div>
    </div>
  );
}
