'use client';

import { useMemo, useState } from 'react';
import { Dish } from '@/lib/types';
import DishGridCard from './DishGridCard';

export default function MenuBrowser({ dishes, currency }: { dishes: Dish[]; currency: string }) {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [query, setQuery] = useState('');

  const categories = useMemo(() => {
    const names = Array.from(new Set(dishes.map((d) => d.categoryName)));
    return names;
  }, [dishes]);

  const filtered = useMemo(() => {
    return dishes.filter((d) => {
      if (activeCategory !== 'all' && d.categoryName !== activeCategory) return false;
      if (query.trim() && !d.name.toLowerCase().includes(query.trim().toLowerCase())) return false;
      return d.isAvailable;
    });
  }, [dishes, activeCategory, query]);

  return (
    <section id="menu" className="max-w-7xl mx-auto px-6 lg:px-10 py-10">
      <div className="flex flex-col md:flex-row md:items-center gap-4 md:gap-6 mb-8">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveCategory('all')}
            className={`px-4 py-2 rounded-full text-sm border transition-colors ${
              activeCategory === 'all'
                ? 'bg-forest-700 border-forest-700 text-parchment-50'
                : 'border-forest-900/15 text-forest-900/70 hover:border-forest-700/40'
            }`}
          >
            Все блюда
          </button>
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setActiveCategory(c)}
              className={`px-4 py-2 rounded-full text-sm border transition-colors ${
                activeCategory === c
                  ? 'bg-forest-700 border-forest-700 text-parchment-50'
                  : 'border-forest-900/15 text-forest-900/70 hover:border-forest-700/40'
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="md:ml-auto relative w-full md:w-64">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Поиск блюд..."
            className="w-full rounded-full border border-forest-900/15 bg-white pl-4 pr-4 py-2.5 text-sm outline-none focus:border-forest-700/50 text-forest-900 placeholder:text-forest-900/35"
          />
        </div>
      </div>

      <div className="flex items-baseline justify-between mb-5">
        <h2 className="font-display italic text-2xl text-forest-900">
          {activeCategory === 'all' ? 'Популярные блюда' : activeCategory}
        </h2>
        <span className="text-sm text-forest-900/40">{filtered.length} блюд</span>
      </div>

      {filtered.length === 0 ? (
        <p className="text-forest-900/50 py-10 text-center">Ничего не найдено — попробуйте другой запрос.</p>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {filtered.map((d) => (
            <DishGridCard key={d.id} dish={d} currency={currency} />
          ))}
        </div>
      )}
    </section>
  );
}
