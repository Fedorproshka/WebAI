import { NextRequest, NextResponse } from 'next/server';
import { getAISettings, getDishesByRestaurant, getRestaurantById, logAnalyticsEvent } from '@/lib/repository';
import { buildChatSystemPrompt, fallbackChatReply, historyToGeminiContents } from '@/lib/ai/chatPrompt';
import { ChatMessage } from '@/lib/types';

export const runtime = 'nodejs';

interface ChatRequestBody {
  restaurantId: string;
  history: ChatMessage[]; // предыдущие сообщения (без последнего пользовательского, если это голос)
  text?: string; // текстовое сообщение пользователя
  audioBase64?: string; // ИЛИ голосовое сообщение (webm/ogg), см. VoiceRecorderButton
  audioMimeType?: string;
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as ChatRequestBody;
    const { restaurantId, history, text, audioBase64, audioMimeType } = body;

    if (!restaurantId || (!text && !audioBase64)) {
      return NextResponse.json({ error: 'restaurantId и text/audioBase64 обязательны' }, { status: 400 });
    }

    const restaurant = await getRestaurantById(restaurantId);
    if (!restaurant) {
      return NextResponse.json({ error: 'Ресторан не найден' }, { status: 404 });
    }

    const [dishes, aiSettings] = await Promise.all([
      getDishesByRestaurant(restaurantId),
      getAISettings(restaurantId),
    ]);

    const systemPrompt = buildChatSystemPrompt({
      restaurantName: restaurant.name,
      aiSettings,
      dishes,
    }).replace('__SLUG__', restaurant.slug);

    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      // Demo-режим без Gemini: голос не поддерживается (нужен Gemini для
      // распознавания речи), честно сообщаем об этом.
      if (audioBase64) {
        return NextResponse.json({
          reply: 'Голосовой режим требует подключённый Gemini API. Сейчас работает только текстовый demo-чат.',
          transcript: null,
        });
      }
      return NextResponse.json({ reply: fallbackChatReply(text ?? '', dishes), transcript: null });
    }

    const { GoogleGenerativeAI } = await import('@google/generative-ai');
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

    const contents = historyToGeminiContents(systemPrompt, history ?? []);

    let transcript: string | null = null;

    if (audioBase64) {
      // Gemini принимает аудио напрямую (мультимодально) — отдельный
      // сервис распознавания речи не нужен. Просим модель сначала
      // транскрибировать реплику гостя, а затем ответить, в предсказуемом
      // формате, чтобы показать в чате и то, что "услышал" AI, и ответ.
      contents.push({
        role: 'user',
        parts: [
          {
            text:
              'Это голосовое сообщение гостя. Ответь СТРОГО в формате:\n' +
              'TRANSCRIPT: <дословная расшифровка сказанного гостем>\n' +
              'REPLY: <твой ответ по правилам выше>',
          } as any,
          { inlineData: { mimeType: audioMimeType || 'audio/webm', data: audioBase64 } } as any,
        ],
      });
    } else {
      contents.push({ role: 'user', parts: [{ text: text! }] });
    }

    const result = await model.generateContent({ contents: contents as any });
    const rawText = result.response.text().trim();

    let replyText = rawText;

    if (audioBase64) {
      const transcriptMatch = rawText.match(/TRANSCRIPT:\s*([\s\S]*?)\nREPLY:/i);
      const replyMatch = rawText.match(/REPLY:\s*([\s\S]*)/i);
      transcript = transcriptMatch ? transcriptMatch[1].trim() : '[не удалось распознать речь]';
      replyText = replyMatch ? replyMatch[1].trim() : rawText;
    }

    await logAnalyticsEvent(restaurantId, 'chat_message', { hasAudio: Boolean(audioBase64) });

    return NextResponse.json({ reply: replyText, transcript });
  } catch (err) {
    console.error('chat API error', err);
    return NextResponse.json({ error: 'Внутренняя ошибка сервера' }, { status: 500 });
  }
}
