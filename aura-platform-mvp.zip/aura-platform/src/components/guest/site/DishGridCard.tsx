'use client';

import Image from 'next/image';
import { Dish } from '@/lib/types';

export default function DishGridCard({ dish, currency }: { dish: Dish; currency: string }) {
  return (
    <div className="group rounded-xl2 bg-white border border-forest-900/8 overflow-hidden hover:shadow-[0_20px_40px_-24px_rgba(21,36,20,0.25)] transition-shadow">
      <div className="relative h-40 sm:h-44 w-full bg-forest-900/5">
        {dish.imageUrl && (
          <Image src={dish.imageUrl} alt={dish.name} fill className="object-cover group-hover:scale-[1.03] transition-transform duration-500" unoptimized />
        )}
      </div>
      <div className="p-5">
        <h3 className="font-display italic text-lg text-forest-900">{dish.name}</h3>
        <p className="mt-1 text-sm text-forest-900/50 line-clamp-2">{dish.description}</p>
        <div className="mt-4 flex items-center justify-between">
          <span className="font-medium text-forest-900">
            {dish.price.toLocaleString('ru-RU')} {currency}
          </span>
          <span className="w-8 h-8 rounded-full border border-forest-900/15 flex items-center justify-center text-forest-900/60 group-hover:bg-forest-700 group-hover:text-parchment-50 group-hover:border-forest-700 transition-colors">
            +
          </span>
        </div>
      </div>
    </div>
  );
}
