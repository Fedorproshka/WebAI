import { AISettings, Dish, DishRecommendation, GuestPreferences, RecommendationResult } from '@/lib/types';
import { buildRecommendationPrompt } from './prompt';
import { fallbackRecommend } from './fallback';

const BUDGET_MAX: Record<GuestPreferences['budget'], number | null> = {
  under3000: 3000,
  '3000-6000': 6000,
  '6000-10000': 10000,
  any: null,
};

/**
 * Шаг 1: предфильтрация меню ДО отправки в AI (п.11 ТЗ — не отправлять всё
 * меню без необходимости). Убираем недоступные блюда, явные конфликты по
 * аллергиям/бюджету, оставляем разумный шорт-лист (до 18 блюд).
 */
export function shortlistDishes(dishes: Dish[], prefs: GuestPreferences): Dish[] {
  const budgetMax = BUDGET_MAX[prefs.budget];
  const excluded = prefs.excludedIngredients
    .toLowerCase()
    .split(/[,;\n]/)
    .map((s) => s.trim())
    .filter(Boolean);

  let pool = dishes.filter((d) => d.isAvailable);

  // Жёсткий фильтр аллергенов — блюда с аллергенами гостя не должны даже
  // попадать в промпт, чтобы исключить риск, что AI их всё же порекомендует.
  pool = pool.filter((d) => !d.allergens.some((a) => prefs.allergies.includes(a)));

  if (excluded.length > 0) {
    pool = pool.filter(
      (d) => !excluded.some((ex) => d.ingredients.some((ing) => ing.toLowerCase().includes(ex))),
    );
  }

  let budgetFiltered = pool;
  if (budgetMax !== null) {
    budgetFiltered = pool.filter((d) => d.price <= budgetMax);
    // Если по бюджету совсем ничего не осталось — лучше показать честный
    // "нет подходящего", поэтому оставляем небольшой запас чуть дороже.
    if (budgetFiltered.length === 0) {
      budgetFiltered = [...pool].sort((a, b) => a.price - b.price).slice(0, 6);
    }
  }

  if (prefs.craving !== 'any') {
    const matching = budgetFiltered.filter((d) => d.tags.includes(prefs.craving as any));
    if (matching.length >= 3) budgetFiltered = matching;
  }

  return budgetFiltered.slice(0, 18);
}

export async function getRecommendations(params: {
  restaurantName: string;
  dishes: Dish[];
  aiSettings: AISettings;
  preferences: GuestPreferences;
}): Promise<RecommendationResult> {
  const { restaurantName, dishes, aiSettings, preferences } = params;
  const shortlist = shortlistDishes(dishes, preferences);

  if (shortlist.length === 0) {
    return { recommendations: [], upsell: null, noGoodMatch: true, note: 'В меню сейчас нет блюд, подходящих под ваш запрос. Попробуйте изменить бюджет или предпочтения.' };
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    // DEMO / без ключа Gemini — используем прозрачный rule-based fallback.
    return fallbackRecommend(shortlist, preferences, aiSettings.upsellEnabled);
  }

  try {
    const { GoogleGenerativeAI } = await import('@google/generative-ai');
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

    const prompt = buildRecommendationPrompt({
      restaurantName,
      aiSettings,
      preferences,
      shortlist,
    });

    const result = await model.generateContent(prompt);
    const text = result.response.text().trim();
    const cleaned = text.replace(/^```json\s*|\s*```$/g, '');
    const parsed = JSON.parse(cleaned);

    return validateAndMap(parsed, shortlist);
  } catch (err) {
    console.error('Gemini error, falling back to rule-based engine:', err);
    return fallbackRecommend(shortlist, preferences, aiSettings.upsellEnabled);
  }
}

/**
 * Валидация ответа модели: ЛЮБОЙ dishId, которого нет в шорт-листе,
 * отбрасывается. Это защита от галлюцинаций — AI физически не может
 * "порекомендовать" блюдо, которого нет в базе ресторана.
 */
function validateAndMap(parsed: any, shortlist: Dish[]): RecommendationResult {
  const byId = new Map(shortlist.map((d) => [d.id, d]));

  const recommendations: DishRecommendation[] = (parsed.recommendations ?? [])
    .filter((r: any) => byId.has(r.dishId))
    .slice(0, 3)
    .map((r: any) => ({
      dish: byId.get(r.dishId)!,
      matchScore: Math.max(0, Math.min(100, Number(r.matchScore) || 0)),
      reason: String(r.reason ?? ''),
      allergenWarning: r.allergenWarning ? String(r.allergenWarning) : null,
    }));

  let upsell: RecommendationResult['upsell'] = null;
  if (parsed.upsell && byId.has(parsed.upsell.dishId)) {
    upsell = {
      dish: byId.get(parsed.upsell.dishId)!,
      message: String(parsed.upsell.message ?? ''),
    };
  }

  if (recommendations.length === 0) {
    return {
      recommendations: [],
      upsell: null,
      noGoodMatch: true,
      note: 'Не удалось подобрать точное совпадение. Попробуйте изменить предпочтения или уточните у персонала.',
    };
  }

  return {
    recommendations,
    upsell,
    noGoodMatch: Boolean(parsed.noGoodMatch),
    note: parsed.note ? String(parsed.note) : null,
  };
}
