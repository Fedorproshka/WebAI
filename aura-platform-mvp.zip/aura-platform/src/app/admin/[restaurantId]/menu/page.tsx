import Link from 'next/link';
import { getDishesByRestaurant, getRestaurantById } from '@/lib/repository';
import { notFound } from 'next/navigation';
import DishTable from '@/components/admin/DishTable';

export default async function MenuPage({ params }: { params: { restaurantId: string } }) {
  const restaurant = await getRestaurantById(params.restaurantId);
  if (!restaurant) notFound();
  const dishes = await getDishesByRestaurant(params.restaurantId);

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-display italic text-3xl">Меню</h1>
        <Link
          href={`/admin/${params.restaurantId}/menu/new`}
          className="px-6 py-2.5 rounded-full bg-brass-500 text-espresso-950 font-medium text-sm hover:bg-brass-400 transition-colors"
        >
          + Добавить блюдо
        </Link>
      </div>
      <DishTable dishes={dishes} restaurantId={params.restaurantId} currency={restaurant.currency} />
    </div>
  );
}
