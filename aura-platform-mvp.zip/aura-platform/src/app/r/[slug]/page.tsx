import { notFound } from 'next/navigation';
import { getAISettings, getDishesByRestaurant, getRestaurantBySlug } from '@/lib/repository';
import SiteHeader from '@/components/guest/site/SiteHeader';
import Hero from '@/components/guest/site/Hero';
import MenuBrowser from '@/components/guest/site/MenuBrowser';
import FeaturesRow from '@/components/guest/site/FeaturesRow';
import ChatWidget from '@/components/guest/chat/ChatWidget';

export default async function RestaurantSitePage({ params }: { params: { slug: string } }) {
  const restaurant = await getRestaurantBySlug(params.slug);
  if (!restaurant) notFound();

  const [dishes, aiSettings] = await Promise.all([
    getDishesByRestaurant(restaurant.id),
    getAISettings(restaurant.id),
  ]);

  const heroDish = dishes.find((d) => d.tags.includes('fish')) ?? dishes[0];

  return (
    <div className="min-h-screen bg-parchment-50 text-forest-900">
      <SiteHeader restaurant={restaurant} />
      <Hero restaurant={restaurant} heroDish={heroDish} />
      <MenuBrowser dishes={dishes} currency={restaurant.currency} />
      <FeaturesRow />

      <footer id="contacts" className="border-t border-forest-900/8 py-10 text-center text-sm text-forest-900/40">
        {restaurant.name} · Сделано на платформе AURA
      </footer>

      <ChatWidget restaurant={restaurant} aiSettings={aiSettings} />
    </div>
  );
}
