'use client';

import Link from 'next/link';
import { Dish } from '@/lib/types';
import { useRouter } from 'next/navigation';

export default function DishTable({ dishes, restaurantId, currency }: { dishes: Dish[]; restaurantId: string; currency: string }) {
  const router = useRouter();

  async function handleDelete(dishId: string) {
    if (!confirm('Удалить это блюдо?')) return;
    const res = await fetch(`/api/dishes?restaurantId=${restaurantId}&dishId=${dishId}`, { method: 'DELETE' });
    if (res.ok) {
      router.refresh();
    } else {
      const data = await res.json().catch(() => ({}));
      alert(data.error === 'DEMO_MODE_READONLY'
        ? 'Demo-режим доступен только для чтения. Подключите Supabase, чтобы редактировать меню.'
        : 'Не удалось удалить блюдо.');
    }
  }

  return (
    <div className="rounded-2xl bg-white border border-espresso-900/10 overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-espresso-950/[0.03] text-espresso-900/50 text-xs uppercase">
          <tr>
            <th className="text-left px-6 py-3">Блюдо</th>
            <th className="text-left px-6 py-3">Категория</th>
            <th className="text-left px-6 py-3">Цена</th>
            <th className="text-left px-6 py-3">Доступно</th>
            <th className="px-6 py-3"></th>
          </tr>
        </thead>
        <tbody>
          {dishes.map((d) => (
            <tr key={d.id} className="border-t border-espresso-900/5 hover:bg-espresso-950/[0.02]">
              <td className="px-6 py-4 font-medium">{d.name}</td>
              <td className="px-6 py-4 text-espresso-900/60">{d.categoryName}</td>
              <td className="px-6 py-4">{d.price.toLocaleString('ru-RU')} {currency}</td>
              <td className="px-6 py-4">
                <span className={`px-2 py-1 rounded-full text-xs ${d.isAvailable ? 'bg-sage-500/15 text-sage-600' : 'bg-clay-500/15 text-clay-500'}`}>
                  {d.isAvailable ? 'да' : 'нет'}
                </span>
              </td>
              <td className="px-6 py-4 text-right whitespace-nowrap">
                <Link href={`/admin/${restaurantId}/menu/${d.id}`} className="text-brass-600 hover:underline mr-4">
                  Редактировать
                </Link>
                <button onClick={() => handleDelete(d.id)} className="text-clay-500 hover:underline">
                  Удалить
                </button>
              </td>
            </tr>
          ))}
          {dishes.length === 0 && (
            <tr>
              <td colSpan={5} className="px-6 py-10 text-center text-espresso-900/40">
                В меню пока нет блюд. Добавьте первое блюдо.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
