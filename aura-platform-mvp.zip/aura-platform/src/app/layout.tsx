import type { Metadata } from 'next';
import { Fraunces, Inter } from 'next/font/google';
import './globals.css';

const fraunces = Fraunces({
  subsets: ['latin', 'cyrillic'],
  variable: '--font-fraunces',
  weight: ['400', '500', '600'],
  style: ['normal', 'italic'],
});

const inter = Inter({
  subsets: ['latin', 'cyrillic'],
  variable: '--font-inter',
  weight: ['400', '500', '600', '700'],
});

export const metadata: Metadata = {
  title: 'AURA — AI-платформа для ресторанов',
  description: 'AI-помощник, который подбирает блюда под предпочтения гостя',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <body className={`${fraunces.variable} ${inter.variable} font-body bg-espresso-950 text-parchment-50`}>
        {children}
      </body>
    </html>
  );
}
