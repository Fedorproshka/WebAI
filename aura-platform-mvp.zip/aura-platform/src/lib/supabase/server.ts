import { createClient } from '@supabase/supabase-js';

// Серверный клиент с service-role key. ИСПОЛЬЗУЕТСЯ ТОЛЬКО в Route Handlers /
// Server Components — ключ никогда не должен попадать в браузер.
const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

export const isSupabaseConfiguredServer = Boolean(url && serviceKey);

export const supabaseServer = isSupabaseConfiguredServer
  ? createClient(url as string, serviceKey as string, {
      auth: { persistSession: false },
    })
  : null;
