'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Allergen, Dish, DishTag } from '@/lib/types';

const ALLERGENS: Allergen[] = ['gluten', 'dairy', 'eggs', 'nuts', 'peanuts', 'fish', 'shellfish', 'soy', 'sesame'];
const TAGS: DishTag[] = ['meat', 'fish', 'pasta', 'light', 'vegetarian', 'vegan', 'spicy', 'mild', 'dessert', 'drink', 'soup', 'salad', 'breakfast'];

interface Props {
  restaurantId: string;
  initial?: Dish;
}

export default function DishForm({ restaurantId, initial }: Props) {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [name, setName] = useState(initial?.name ?? '');
  const [categoryName, setCategoryName] = useState(initial?.categoryName ?? '');
  const [price, setPrice] = useState(initial?.price?.toString() ?? '');
  const [description, setDescription] = useState(initial?.description ?? '');
  const [imageUrl, setImageUrl] = useState(initial?.imageUrl ?? '');
  const [ingredients, setIngredients] = useState(initial?.ingredients.join(', ') ?? '');
  const [allergens, setAllergens] = useState<Allergen[]>(initial?.allergens ?? []);
  const [allergenInfoComplete, setAllergenInfoComplete] = useState(initial?.allergenInfoComplete ?? true);
  const [tags, setTags] = useState<DishTag[]>(initial?.tags ?? []);
  const [spiceLevel, setSpiceLevel] = useState(initial?.spiceLevel ?? 0);
  const [isAvailable, setIsAvailable] = useState(initial?.isAvailable ?? true);

  const toggleFrom = <T,>(arr: T[], setArr: (v: T[]) => void, value: T) => {
    setArr(arr.includes(value) ? arr.filter((v) => v !== value) : [...arr, value]);
  };

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const dish: Dish = {
      id: initial?.id ?? crypto.randomUUID(),
      restaurantId,
      categoryId: initial?.categoryId ?? categoryName.toLowerCase().replace(/\s+/g, '-'),
      categoryName,
      name,
      description,
      price: Number(price) || 0,
      imageUrl: imageUrl || null,
      ingredients: ingredients.split(',').map((i) => i.trim()).filter(Boolean),
      allergens,
      allergenInfoComplete,
      tags,
      spiceLevel: spiceLevel as 0 | 1 | 2 | 3,
      isAvailable,
    };

    const res = await fetch('/api/dishes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dish),
    });

    setSaving(false);

    if (res.ok) {
      router.push(`/admin/${restaurantId}/menu`);
      router.refresh();
    } else {
      const data = await res.json().catch(() => ({}));
      setError(
        data.error === 'DEMO_MODE_READONLY'
          ? 'Demo-режим доступен только для чтения. Подключите Supabase (см. .env.local.example), чтобы сохранять изменения меню.'
          : data.error ?? 'Не удалось сохранить блюдо.',
      );
    }
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl space-y-6">
      {error && (
        <div className="rounded-xl bg-clay-500/10 border border-clay-500/30 px-4 py-3 text-sm text-espresso-900">
          {error}
        </div>
      )}

      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs text-espresso-900/60 mb-1">Название блюда</label>
          <input required value={name} onChange={(e) => setName(e.target.value)} className="w-full rounded-xl border border-espresso-900/15 px-4 py-2.5 outline-none focus:border-brass-500" />
        </div>
        <div>
          <label className="block text-xs text-espresso-900/60 mb-1">Категория</label>
          <input required value={categoryName} onChange={(e) => setCategoryName(e.target.value)} placeholder="Например: Основные блюда" className="w-full rounded-xl border border-espresso-900/15 px-4 py-2.5 outline-none focus:border-brass-500" />
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs text-espresso-900/60 mb-1">Цена (₸)</label>
          <input required type="number" min={0} value={price} onChange={(e) => setPrice(e.target.value)} className="w-full rounded-xl border border-espresso-900/15 px-4 py-2.5 outline-none focus:border-brass-500" />
        </div>
        <div>
          <label className="block text-xs text-espresso-900/60 mb-1">Ссылка на фото</label>
          <input value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} placeholder="https://..." className="w-full rounded-xl border border-espresso-900/15 px-4 py-2.5 outline-none focus:border-brass-500" />
        </div>
      </div>

      <div>
        <label className="block text-xs text-espresso-900/60 mb-1">Описание</label>
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} className="w-full rounded-xl border border-espresso-900/15 px-4 py-2.5 outline-none focus:border-brass-500 resize-none" />
      </div>

      <div>
        <label className="block text-xs text-espresso-900/60 mb-1">Состав (через запятую)</label>
        <input value={ingredients} onChange={(e) => setIngredients(e.target.value)} placeholder="говядина, булка, сыр" className="w-full rounded-xl border border-espresso-900/15 px-4 py-2.5 outline-none focus:border-brass-500" />
      </div>

      <div>
        <label className="block text-xs text-espresso-900/60 mb-2">Аллергены</label>
        <div className="flex flex-wrap gap-2">
          {ALLERGENS.map((a) => (
            <button type="button" key={a} onClick={() => toggleFrom(allergens, setAllergens, a)}
              className={`px-3 py-1.5 rounded-full text-xs border ${allergens.includes(a) ? 'bg-clay-500/15 border-clay-500 text-clay-500' : 'border-espresso-900/15 text-espresso-900/60'}`}>
              {a}
            </button>
          ))}
        </div>
        <label className="flex items-center gap-2 mt-3 text-xs text-espresso-900/60">
          <input type="checkbox" checked={allergenInfoComplete} onChange={(e) => setAllergenInfoComplete(e.target.checked)} />
          Информация об аллергенах полная и проверена
        </label>
      </div>

      <div>
        <label className="block text-xs text-espresso-900/60 mb-2">Характеристики блюда</label>
        <div className="flex flex-wrap gap-2">
          {TAGS.map((t) => (
            <button type="button" key={t} onClick={() => toggleFrom(tags, setTags, t)}
              className={`px-3 py-1.5 rounded-full text-xs border ${tags.includes(t) ? 'bg-brass-500/15 border-brass-500 text-brass-600' : 'border-espresso-900/15 text-espresso-900/60'}`}>
              {t}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-xs text-espresso-900/60 mb-1">Уровень остроты</label>
        <select value={spiceLevel} onChange={(e) => setSpiceLevel(Number(e.target.value))} className="rounded-xl border border-espresso-900/15 px-4 py-2.5">
          <option value={0}>Не острое</option>
          <option value={1}>Слегка острое</option>
          <option value={2}>Средне острое</option>
          <option value={3}>Очень острое</option>
        </select>
      </div>

      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={isAvailable} onChange={(e) => setIsAvailable(e.target.checked)} />
        Блюдо доступно в меню
      </label>

      <button disabled={saving} type="submit" className="px-8 py-3 rounded-full bg-brass-500 text-espresso-950 font-medium hover:bg-brass-400 disabled:opacity-50 transition-colors">
        {saving ? 'Сохраняем…' : 'Сохранить блюдо'}
      </button>
    </form>
  );
}
