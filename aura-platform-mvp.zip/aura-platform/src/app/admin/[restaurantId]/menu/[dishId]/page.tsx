import { notFound } from 'next/navigation';
import { getDishesByRestaurant } from '@/lib/repository';
import DishForm from '@/components/admin/DishForm';

export default async function EditDishPage({ params }: { params: { restaurantId: string; dishId: string } }) {
  const dishes = await getDishesByRestaurant(params.restaurantId);
  const dish = dishes.find((d) => d.id === params.dishId);
  if (!dish) notFound();

  return (
    <div>
      <h1 className="font-display italic text-3xl mb-8">Редактировать блюдо</h1>
      <DishForm restaurantId={params.restaurantId} initial={dish} />
    </div>
  );
}
