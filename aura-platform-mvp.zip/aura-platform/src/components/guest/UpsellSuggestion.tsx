'use client';

import { RecommendationResult } from '@/lib/types';

interface Props {
  upsell: NonNullable<RecommendationResult['upsell']>;
  currency: string;
}

export default function UpsellSuggestion({ upsell, currency }: Props) {
  return (
    <div className="mt-4 flex items-center gap-4 rounded-2xl border border-sage-500/20 bg-sage-500/5 px-5 py-4 animate-fadeUp">
      <div className="w-2 h-2 rounded-full bg-sage-400 shrink-0" />
      <p className="text-sm text-parchment-100/80 flex-1">
        {upsell.message}{' '}
        <span className="text-sage-400 font-medium">
          {upsell.dish.name} — {upsell.dish.price.toLocaleString('ru-RU')} {currency}
        </span>
      </p>
    </div>
  );
}
