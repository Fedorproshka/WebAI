import { NextRequest, NextResponse } from 'next/server';
import { getAISettings, getDishesByRestaurant, getRestaurantById, logAnalyticsEvent } from '@/lib/repository';
import { getRecommendations } from '@/lib/ai/recommend';
import { GuestPreferences } from '@/lib/types';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { restaurantId, preferences } = body as {
      restaurantId: string;
      preferences: GuestPreferences;
    };

    if (!restaurantId || !preferences) {
      return NextResponse.json({ error: 'restaurantId и preferences обязательны' }, { status: 400 });
    }

    // Изоляция: все данные ниже запрашиваются строго по restaurantId,
    // так что ответ никогда не будет содержать блюда другого ресторана.
    const restaurant = await getRestaurantById(restaurantId);
    if (!restaurant) {
      return NextResponse.json({ error: 'Ресторан не найден' }, { status: 404 });
    }

    const [dishes, aiSettings] = await Promise.all([
      getDishesByRestaurant(restaurantId),
      getAISettings(restaurantId),
    ]);

    const result = await getRecommendations({
      restaurantName: restaurant.name,
      dishes,
      aiSettings,
      preferences,
    });

    await logAnalyticsEvent(restaurantId, 'recommendation_generated', {
      preferences,
      dishIds: result.recommendations.map((r) => r.dish.id),
    });

    return NextResponse.json(result);
  } catch (err) {
    console.error('recommend API error', err);
    return NextResponse.json({ error: 'Внутренняя ошибка сервера' }, { status: 500 });
  }
}
