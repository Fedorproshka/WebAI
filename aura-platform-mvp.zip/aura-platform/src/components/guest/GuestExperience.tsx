'use client';

import { useState } from 'react';
import { AISettings, GuestPreferences, RecommendationResult, Restaurant } from '@/lib/types';
import WelcomeScreen from './WelcomeScreen';
import QuestionFlow from './QuestionFlow';
import RecommendationResults from './RecommendationResults';

type Stage = 'welcome' | 'questions' | 'loading' | 'results' | 'error';

interface Props {
  restaurant: Restaurant;
  aiSettings: AISettings;
}

export default function GuestExperience({ restaurant, aiSettings }: Props) {
  const [stage, setStage] = useState<Stage>('welcome');
  const [result, setResult] = useState<RecommendationResult | null>(null);

  async function handleComplete(preferences: GuestPreferences) {
    setStage('loading');
    try {
      const res = await fetch('/api/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ restaurantId: restaurant.id, preferences }),
      });
      if (!res.ok) throw new Error('request failed');
      const data: RecommendationResult = await res.json();
      setResult(data);
      setStage('results');
    } catch (e) {
      setStage('error');
    }
  }

  if (stage === 'welcome') {
    return (
      <WelcomeScreen restaurant={restaurant} aiSettings={aiSettings} onStart={() => setStage('questions')} />
    );
  }

  if (stage === 'questions') {
    return <QuestionFlow onComplete={handleComplete} />;
  }

  if (stage === 'loading') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4">
        <div className="w-10 h-10 rounded-full border-2 border-brass-500/30 border-t-brass-400 animate-spin" />
        <p className="text-parchment-200/60 text-sm">Подбираем блюда специально для вас…</p>
      </div>
    );
  }

  if (stage === 'error') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 px-6 text-center">
        <p className="text-parchment-100">Не получилось получить рекомендации. Попробуйте ещё раз.</p>
        <button
          onClick={() => setStage('welcome')}
          className="px-6 py-3 rounded-full bg-brass-500 text-espresso-950 font-medium"
        >
          Начать заново
        </button>
      </div>
    );
  }

  if (stage === 'results' && result) {
    return (
      <RecommendationResults result={result} currency={restaurant.currency} onRestart={() => setStage('welcome')} />
    );
  }

  return null;
}
