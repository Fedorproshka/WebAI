'use client';

import { RecommendationResult } from '@/lib/types';
import RecommendationCard from './RecommendationCard';
import UpsellSuggestion from './UpsellSuggestion';

interface Props {
  result: RecommendationResult;
  currency: string;
  onRestart: () => void;
}

export default function RecommendationResults({ result, currency, onRestart }: Props) {
  return (
    <div className="min-h-screen px-6 py-16 animate-fadeUp">
      <div className="max-w-3xl mx-auto">
        <span className="text-brass-400 tracking-[0.25em] text-xs uppercase">Ваш подбор</span>
        <h2 className="font-display text-3xl md:text-4xl italic text-parchment-50 mt-2 mb-3 text-balance">
          {result.recommendations.length > 0 ? 'Вот что подойдёт вам лучше всего' : 'Не нашли идеального совпадения'}
        </h2>

        {result.note && (
          <p className="text-sm text-parchment-200/60 mb-8 max-w-lg">{result.note}</p>
        )}

        <div className="grid md:grid-cols-3 gap-5">
          {result.recommendations.map((rec, i) => (
            <RecommendationCard key={rec.dish.id} rec={rec} rank={i} currency={currency} />
          ))}
        </div>

        {result.upsell && <UpsellSuggestion upsell={result.upsell} currency={currency} />}

        {result.recommendations.length === 0 && (
          <p className="text-parchment-200/60 mt-4">
            Пожалуйста, обратитесь к персоналу — они с радостью помогут подобрать блюдо.
          </p>
        )}

        <button
          onClick={onRestart}
          className="mt-10 text-sm text-parchment-200/50 hover:text-brass-400 transition-colors"
        >
          ← Пройти опрос заново
        </button>
      </div>
    </div>
  );
}
