import { AISettings, ChatMessage, Dish } from '@/lib/types';

/**
 * Промпт для разговорного AI-виджета (в отличие от prompt.ts, который строит
 * строгий JSON-опрос для полноэкранного визарда). Здесь AI ведёт свободный
 * диалог, но всё так же ограничен реальным меню ресторана — не JSON-ответ,
 * а обычный текст, поэтому в system-инструкции жёстко запрещаем выдумывать
 * блюда/цены/ингредиенты, которых нет в списке.
 */
export function buildChatSystemPrompt(params: {
  restaurantName: string;
  aiSettings: AISettings;
  dishes: Dish[];
}): string {
  const { restaurantName, aiSettings, dishes } = params;

  const toneInstruction =
    aiSettings.tone === 'professional'
      ? 'Общайся сдержанно и профессионально, как метрдотель high-end ресторана.'
      : aiSettings.tone === 'playful'
        ? 'Общайся легко, дружелюбно, с лёгкой игривостью, но без фамильярности.'
        : 'Общайся тепло и по-человечески, как внимательный официант.';

  const menuJson = dishes.map((d) => ({
    id: d.id,
    name: d.name,
    category: d.categoryName,
    description: d.description,
    price: d.price,
    ingredients: d.ingredients,
    allergens: d.allergens,
    allergenInfoComplete: d.allergenInfoComplete,
    tags: d.tags,
    spiceLevel: d.spiceLevel,
    available: d.isAvailable,
  }));

  return `Ты — голосовой и текстовый AI-помощник ресторана "${restaurantName}". Ты помогаешь гостю выбрать блюда, отвечаешь на вопросы о меню, составе, аллергенах и ценах.

СТРОГИЕ ПРАВИЛА:
1. Используй ТОЛЬКО блюда и данные из меню ниже. Никогда не придумывай блюда, ингредиенты, цены или свойства, которых там нет.
2. Если гость упоминает аллергию, а у блюда allergenInfoComplete=false — обязательно предупреди, что информацию нужно уточнить у персонала, даже если явных совпадений не видно.
3. Если гость упоминает аллергию, совпадающую с allergens блюда, которое ты хочешь предложить — не предлагай его, объясни почему.
4. Отвечай коротко (2-4 предложения), разговорным языком, без markdown и списков — это должно звучать естественно и в голосовом варианте тоже.
5. Если гость просит "подобрать блюдо под предпочтения" развёрнуто (несколько критериев сразу) — можно предложить пройти короткий AI-опрос по ссылке /r/__SLUG__/survey, но только если это действительно уместно, не навязывай на каждом сообщении.
6. ${toneInstruction}
${aiSettings.systemPromptExtra ? `7. Доп. инструкции ресторана: ${aiSettings.systemPromptExtra}` : ''}

Меню ресторана (используй только эти данные):
${JSON.stringify(menuJson, null, 2)}`;
}

export function historyToGeminiContents(
  systemPrompt: string,
  history: ChatMessage[],
): { role: 'user' | 'model'; parts: { text: string }[] }[] {
  const contents: { role: 'user' | 'model'; parts: { text: string }[] }[] = [
    { role: 'user', parts: [{ text: systemPrompt }] },
    { role: 'model', parts: [{ text: 'Понял, буду использовать только это меню и следовать правилам.' }] },
  ];
  history.forEach((m) => {
    contents.push({ role: m.role === 'user' ? 'user' : 'model', parts: [{ text: m.text }] });
  });
  return contents;
}

/** Прозрачный fallback без Gemini — простые заранее заготовленные ответы,
 * чтобы виджет не был пустым, если ключ не настроен. */
export function fallbackChatReply(userText: string, dishes: Dish[]): string {
  const lower = userText.toLowerCase();
  const found = dishes.find((d) => lower.includes(d.name.toLowerCase()));
  if (found) {
    return `«${found.name}» — ${found.description}. Стоит ${found.price.toLocaleString('ru-RU')} ₸. Состав: ${found.ingredients.join(', ')}.`;
  }
  return 'Чтобы дать точный ответ по меню, ресторану нужно подключить Gemini API — сейчас я работаю в demo-режиме. Попробуйте пройти короткий AI-опрос — там подбор работает и без ключа.';
}
