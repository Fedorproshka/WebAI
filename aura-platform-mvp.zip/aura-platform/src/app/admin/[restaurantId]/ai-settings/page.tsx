import { getAISettings } from '@/lib/repository';
import AISettingsForm from '@/components/admin/AISettingsForm';

export default async function AISettingsPage({ params }: { params: { restaurantId: string } }) {
  const settings = await getAISettings(params.restaurantId);
  return (
    <div>
      <h1 className="font-display italic text-3xl mb-8">Настройки AI</h1>
      <AISettingsForm initial={settings} />
    </div>
  );
}
