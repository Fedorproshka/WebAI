import { DashboardStats } from '@/lib/analytics';

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-2xl bg-white border border-espresso-900/10 p-6">
      <p className="text-xs uppercase tracking-wide text-espresso-900/50">{label}</p>
      <p className="font-display italic text-3xl mt-2">{value}</p>
    </div>
  );
}

export default function DashboardStatsView({ stats }: { stats: DashboardStats }) {
  return (
    <div>
      {!stats.isLiveData && (
        <div className="mb-6 rounded-xl bg-brass-500/10 border border-brass-500/30 px-4 py-3 text-sm text-espresso-900/70">
          Подключите Supabase, чтобы видеть реальную аналитику по рекомендациям и гостям. Сейчас показано только количество блюд в меню.
        </div>
      )}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard label="Блюд в меню" value={stats.dishCount} />
        <StatCard label="Рекомендаций сгенерировано" value={stats.recommendationCount} />
        <StatCard label="Гостей воспользовались AI" value={stats.guestSessionsCount} />
        <StatCard label="Средний чек" value="—" />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="rounded-2xl bg-white border border-espresso-900/10 p-6">
          <h3 className="font-display italic text-lg mb-4">Самые рекомендуемые блюда</h3>
          {stats.topDishes.length === 0 ? (
            <p className="text-sm text-espresso-900/40">Пока нет данных</p>
          ) : (
            <ul className="space-y-2">
              {stats.topDishes.map((d) => (
                <li key={d.name} className="flex justify-between text-sm">
                  <span>{d.name}</span>
                  <span className="text-espresso-900/50">{d.count}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="rounded-2xl bg-white border border-espresso-900/10 p-6">
          <h3 className="font-display italic text-lg mb-4">Популярные категории</h3>
          {stats.topCategories.length === 0 ? (
            <p className="text-sm text-espresso-900/40">Пока нет данных</p>
          ) : (
            <ul className="space-y-2">
              {stats.topCategories.map((c) => (
                <li key={c.name} className="flex justify-between text-sm">
                  <span>{c.name}</span>
                  <span className="text-espresso-900/50">{c.count}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
