'use client';

import { useVoiceRecorder } from './useVoiceRecorder';

interface Props {
  disabled?: boolean;
  onRecorded: (base64: string, mimeType: string) => void;
}

/** Компактная кнопка микрофона для текстового режима чата. */
export default function VoiceRecorderButton({ disabled, onRecorded }: Props) {
  const { recording, unsupported, toggle } = useVoiceRecorder(onRecorded);

  if (unsupported) {
    return (
      <span className="text-[11px] text-forest-900/40 px-2" title="Микрофон недоступен в этом браузере">
        голос недоступен
      </span>
    );
  }

  return (
    <button
      type="button"
      disabled={disabled}
      onClick={toggle}
      aria-label={recording ? 'Остановить запись' : 'Записать голосовое сообщение'}
      className={`w-10 h-10 shrink-0 rounded-full flex items-center justify-center transition-colors disabled:opacity-40 ${
        recording ? 'bg-clay-500 text-white animate-pulseRing' : 'bg-forest-900/5 text-forest-900 hover:bg-forest-900/10'
      }`}
    >
      {recording ? <StopIcon /> : <MicIcon />}
    </button>
  );
}

function MicIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3Z" />
      <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
      <line x1="12" y1="19" x2="12" y2="23" />
    </svg>
  );
}

function StopIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
      <rect x="5" y="5" width="14" height="14" rx="2" />
    </svg>
  );
}
