'use client';

import { useEffect, useRef, useState } from 'react';
import { AISettings, ChatMessage, Restaurant } from '@/lib/types';
import ChatMessageBubble from './ChatMessageBubble';
import VoiceRecorderButton from './VoiceRecorderButton';
import VoiceOrb from './VoiceOrb';
import { useVoiceRecorder } from './useVoiceRecorder';

const QUICK_QUESTIONS = [
  { icon: '🍽️', label: 'Что вы посоветуете сегодня?' },
  { icon: '🌿', label: 'У меня есть аллергия' },
  { icon: '🥗', label: 'Хочу что-то лёгкое' },
  { icon: '🍷', label: 'Подбор блюда и напитка' },
];

type Mode = 'voice' | 'text';
type OrbState = 'idle' | 'recording' | 'thinking' | 'speaking';

interface Props {
  restaurant: Restaurant;
  aiSettings: AISettings;
}

export default function ChatWidget({ restaurant, aiSettings }: Props) {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<Mode>('voice'); // голосовой диалог — режим по умолчанию
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'greeting',
      role: 'assistant',
      text:
        aiSettings.greeting ||
        `Привет! Я AI-помощник ${restaurant.name}. Нажмите на кнопку и расскажите голосом, что вам хочется — я подберу блюдо и отвечу вслух.`,
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [orbState, setOrbState] = useState<OrbState>('idle');
  const [voiceOutputEnabled, setVoiceOutputEnabled] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, loading]);

  const recorder = useVoiceRecorder((base64, mimeType) => sendVoice(base64, mimeType));

  useEffect(() => {
    setOrbState(recorder.recording ? 'recording' : loading ? 'thinking' : 'idle');
  }, [recorder.recording, loading]);

  async function sendText(text: string) {
    if (!text.trim() || loading) return;
    const userMsg: ChatMessage = { id: crypto.randomUUID(), role: 'user', text };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ restaurantId: restaurant.id, history: messages, text }),
      });
      const data = await res.json();
      const replyText = data.reply ?? 'Извините, не получилось ответить. Попробуйте ещё раз.';
      setMessages((prev) => [...prev, { id: crypto.randomUUID(), role: 'assistant', text: replyText }]);
      if (voiceOutputEnabled) await playVoice(replyText);
    } catch {
      setMessages((prev) => [...prev, { id: crypto.randomUUID(), role: 'assistant', text: 'Ошибка соединения. Попробуйте ещё раз.' }]);
    } finally {
      setLoading(false);
    }
  }

  async function sendVoice(base64: string, mimeType: string) {
    if (loading) return;
    setLoading(true);
    const placeholderId = crypto.randomUUID();
    setMessages((prev) => [...prev, { id: placeholderId, role: 'user', text: '…', isVoice: true }]);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          restaurantId: restaurant.id,
          history: messages,
          audioBase64: base64,
          audioMimeType: mimeType,
        }),
      });
      const data = await res.json();

      setMessages((prev) =>
        prev.map((m) => (m.id === placeholderId ? { ...m, text: data.transcript || '[голосовое сообщение]' } : m)),
      );
      const replyText = data.reply ?? 'Извините, не получилось ответить.';
      setMessages((prev) => [...prev, { id: crypto.randomUUID(), role: 'assistant', text: replyText }]);
      if (voiceOutputEnabled) await playVoice(replyText);
    } catch {
      setMessages((prev) => [...prev, { id: crypto.randomUUID(), role: 'assistant', text: 'Ошибка соединения. Попробуйте ещё раз.' }]);
    } finally {
      setLoading(false);
    }
  }

  async function playVoice(text: string) {
    try {
      const res = await fetch('/api/voice/speak', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
      if (!res.ok) return; // ElevenLabs не настроен — тихо продолжаем без озвучки
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      if (audioRef.current) {
        audioRef.current.src = url;
        setOrbState('speaking');
        await audioRef.current.play().catch(() => {});
      }
    } catch {
      // озвучка недоступна — молча продолжаем
    }
  }

  return (
    <>
      <audio ref={audioRef} hidden onEnded={() => setOrbState('idle')} />

      {!open && (
        <button
          onClick={() => setOpen(true)}
          aria-label="Открыть AI-помощника"
          className="fixed bottom-6 right-6 z-40 w-16 h-16 rounded-full bg-forest-700 text-parchment-50 shadow-[0_12px_30px_-8px_rgba(21,36,20,0.5)] hover:bg-forest-900 transition-colors flex items-center justify-center"
        >
          <SparkleIcon />
        </button>
      )}

      {open && (
        <div className="fixed bottom-6 right-6 z-40 w-[calc(100vw-2rem)] sm:w-96 h-[min(640px,calc(100vh-3rem))] bg-white rounded-2xl shadow-[0_30px_60px_-15px_rgba(21,36,20,0.35)] border border-forest-900/8 flex flex-col overflow-hidden animate-fadeUp">
          <div className="flex items-center gap-3 px-5 py-4 border-b border-forest-900/8">
            <span className="w-9 h-9 rounded-full bg-forest-700 flex items-center justify-center text-parchment-50">
              <SparkleIcon small />
            </span>
            <div className="flex-1">
              <p className="text-sm font-medium text-forest-900">AI-помощник</p>
              <p className="text-xs text-forest-900/50">Ваш персональный гастро-консультант</p>
            </div>
            <button onClick={() => setOpen(false)} aria-label="Закрыть" className="text-forest-900/40 hover:text-forest-900 text-lg leading-none">
              ×
            </button>
          </div>

          {/* Переключатель режима: голос (по умолчанию) / текст */}
          <div className="flex items-center gap-1 mx-4 mt-3 p-1 rounded-full bg-forest-900/5">
            <button
              onClick={() => setMode('voice')}
              className={`flex-1 text-xs py-1.5 rounded-full transition-colors ${mode === 'voice' ? 'bg-white shadow-sm text-forest-900 font-medium' : 'text-forest-900/50'}`}
            >
              🎙 Голосом
            </button>
            <button
              onClick={() => setMode('text')}
              className={`flex-1 text-xs py-1.5 rounded-full transition-colors ${mode === 'text' ? 'bg-white shadow-sm text-forest-900 font-medium' : 'text-forest-900/50'}`}
            >
              ⌨ Текстом
            </button>
          </div>

          {mode === 'voice' ? (
            <div className="flex-1 flex flex-col overflow-hidden">
              <VoiceOrb
                state={orbState}
                onPress={() => {
                  if (recorder.recording) recorder.stop();
                  else recorder.start();
                }}
              />
              {recorder.unsupported && (
                <p className="text-center text-xs text-clay-500 -mt-2 mb-2 px-6">
                  Микрофон недоступен в этом браузере. Переключитесь на текстовый режим.
                </p>
              )}

              <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 pb-3 space-y-3">
                {messages.map((m) => (
                  <ChatMessageBubble key={m.id} message={m} />
                ))}

                {messages.length <= 1 && (
                  <div className="grid gap-2 pt-1">
                    <p className="text-xs text-forest-900/40 px-1">Или спросите текстом:</p>
                    {QUICK_QUESTIONS.slice(0, 2).map((q) => (
                      <button
                        key={q.label}
                        onClick={() => sendText(q.label)}
                        className="flex items-center gap-2 text-left text-sm text-forest-900/80 bg-parchment-50 border border-forest-900/10 rounded-xl px-4 py-2.5 hover:border-forest-700/40 transition-colors"
                      >
                        <span>{q.icon}</span> {q.label}
                      </button>
                    ))}
                    <a
                      href={`/r/${restaurant.slug}/survey`}
                      className="flex items-center gap-2 text-left text-sm text-forest-700 bg-forest-700/5 border border-forest-700/20 rounded-xl px-4 py-2.5 hover:bg-forest-700/10 transition-colors"
                    >
                      ✨ Пройти полный AI-опрос по вкусу
                    </a>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <>
              <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4 space-y-3 bg-parchment-50/50">
                {messages.map((m) => (
                  <ChatMessageBubble key={m.id} message={m} />
                ))}
                {loading && (
                  <div className="flex justify-start">
                    <div className="bg-forest-900/5 rounded-2xl rounded-bl-sm px-4 py-3 text-sm text-forest-900/40">
                      печатает…
                    </div>
                  </div>
                )}

                {messages.length <= 1 && (
                  <div className="grid gap-2 pt-1">
                    {QUICK_QUESTIONS.map((q) => (
                      <button
                        key={q.label}
                        onClick={() => sendText(q.label)}
                        className="flex items-center gap-2 text-left text-sm text-forest-900/80 bg-white border border-forest-900/10 rounded-xl px-4 py-2.5 hover:border-forest-700/40 transition-colors"
                      >
                        <span>{q.icon}</span> {q.label}
                      </button>
                    ))}
                    <a
                      href={`/r/${restaurant.slug}/survey`}
                      className="flex items-center gap-2 text-left text-sm text-forest-700 bg-forest-700/5 border border-forest-700/20 rounded-xl px-4 py-2.5 hover:bg-forest-700/10 transition-colors"
                    >
                      ✨ Пройти полный AI-опрос по вкусу
                    </a>
                  </div>
                )}
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  sendText(input);
                }}
                className="flex items-center gap-2 p-3 border-t border-forest-900/8"
              >
                <VoiceRecorderButton disabled={loading} onRecorded={sendVoice} />
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Напишите ваш вопрос..."
                  className="flex-1 rounded-full bg-forest-900/5 px-4 py-2.5 text-sm outline-none focus:bg-forest-900/[0.07] text-forest-900 placeholder:text-forest-900/35"
                />
                <button
                  type="submit"
                  disabled={loading || !input.trim()}
                  aria-label="Отправить"
                  className="w-10 h-10 shrink-0 rounded-full bg-forest-700 text-parchment-50 flex items-center justify-center disabled:opacity-40 hover:bg-forest-900 transition-colors"
                >
                  <SendIcon />
                </button>
              </form>
            </>
          )}

          <div className="flex items-center justify-between px-4 pb-2 pt-1">
            <button
              onClick={() => setVoiceOutputEnabled((v) => !v)}
              title={voiceOutputEnabled ? 'Озвучка ответов включена' : 'Озвучка ответов выключена'}
              className={`text-[11px] px-2 py-1 rounded-full border ${voiceOutputEnabled ? 'border-forest-700 text-forest-700' : 'border-forest-900/15 text-forest-900/40'}`}
            >
              {voiceOutputEnabled ? '🔊 Озвучка вкл' : '🔇 Озвучка выкл'}
            </button>
            <p className="text-[10px] text-forest-900/30">Работает на базе AI</p>
          </div>
        </div>
      )}
    </>
  );
}

function SparkleIcon({ small }: { small?: boolean }) {
  const s = small ? 16 : 26;
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 2l1.8 5.2L19 9l-5.2 1.8L12 16l-1.8-5.2L5 9l5.2-1.8L12 2z" />
    </svg>
  );
}

function SendIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
      <path d="M2 21l21-9L2 3v7l15 2-15 2v7z" />
    </svg>
  );
}
