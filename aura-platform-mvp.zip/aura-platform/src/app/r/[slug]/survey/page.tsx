import { notFound } from 'next/navigation';
import { getAISettings, getRestaurantBySlug } from '@/lib/repository';
import GuestExperience from '@/components/guest/GuestExperience';

export default async function GuestPage({ params }: { params: { slug: string } }) {
  const restaurant = await getRestaurantBySlug(params.slug);
  if (!restaurant) notFound();

  const aiSettings = await getAISettings(restaurant.id);

  return <GuestExperience restaurant={restaurant} aiSettings={aiSettings} />;
}
