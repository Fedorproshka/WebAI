'use client';

type OrbState = 'idle' | 'recording' | 'thinking' | 'speaking';

const STATE_LABEL: Record<OrbState, string> = {
  idle: 'Нажмите и скажите, что хотите',
  recording: 'Слушаю вас…',
  thinking: 'Думаю…',
  speaking: 'Отвечаю…',
};

export default function VoiceOrb({ state, onPress }: { state: OrbState; onPress: () => void }) {
  return (
    <div className="flex flex-col items-center py-6">
      <button
        onClick={onPress}
        disabled={state === 'thinking' || state === 'speaking'}
        aria-label={state === 'recording' ? 'Остановить запись' : 'Начать говорить'}
        className="relative w-28 h-28 rounded-full flex items-center justify-center disabled:cursor-default"
      >
        {/* внешние кольца-пульсации */}
        {state === 'recording' && (
          <>
            <span className="absolute inset-0 rounded-full bg-clay-500/20 animate-ping" />
            <span className="absolute -inset-3 rounded-full border border-clay-500/30 animate-pulseRing" />
          </>
        )}
        {state === 'speaking' && (
          <span className="absolute -inset-2 rounded-full border-2 border-sage-400/50 animate-pulseRing" />
        )}
        {state === 'thinking' && (
          <span className="absolute inset-0 rounded-full border-2 border-brass-400/40 border-t-brass-500 animate-spin" />
        )}

        <span
          className={`relative w-24 h-24 rounded-full flex items-center justify-center transition-colors ${
            state === 'recording'
              ? 'bg-clay-500 text-white'
              : state === 'speaking'
                ? 'bg-sage-500 text-white'
                : 'bg-forest-700 text-parchment-50'
          }`}
        >
          {state === 'thinking' ? <DotsIcon /> : <MicIcon />}
        </span>
      </button>
      <p className="mt-4 text-sm text-forest-900/60">{STATE_LABEL[state]}</p>
    </div>
  );
}

function MicIcon() {
  return (
    <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3Z" />
      <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
      <line x1="12" y1="19" x2="12" y2="23" />
    </svg>
  );
}

function DotsIcon() {
  return (
    <div className="flex gap-1.5">
      <span className="w-2 h-2 rounded-full bg-white/90 animate-bounce [animation-delay:-0.3s]" />
      <span className="w-2 h-2 rounded-full bg-white/90 animate-bounce [animation-delay:-0.15s]" />
      <span className="w-2 h-2 rounded-full bg-white/90 animate-bounce" />
    </div>
  );
}
