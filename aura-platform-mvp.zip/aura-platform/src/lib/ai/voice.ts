/**
 * Озвучка ответа AI через ElevenLabs (платный внешний API, выбран пользователем
 * за качество голоса). Требует ELEVENLABS_API_KEY в .env.local.
 * Голос настраивается через ELEVENLABS_VOICE_ID (по умолчанию — стандартный
 * многоязычный голос ElevenLabs, поддерживающий русский).
 */

const DEFAULT_VOICE_ID = 'EXAVITQu4vr4xnSDxMaL'; // "Sarah" — стандартный голос ElevenLabs (multilingual)

export async function synthesizeSpeech(text: string): Promise<{ audio: ArrayBuffer; contentType: string } | null> {
  const apiKey = process.env.ELEVENLABS_API_KEY;
  if (!apiKey) return null;

  const voiceId = process.env.ELEVENLABS_VOICE_ID || DEFAULT_VOICE_ID;

  const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
    method: 'POST',
    headers: {
      'xi-api-key': apiKey,
      'Content-Type': 'application/json',
      accept: 'audio/mpeg',
    },
    body: JSON.stringify({
      text,
      model_id: 'eleven_multilingual_v2',
      voice_settings: { stability: 0.4, similarity_boost: 0.8 },
    }),
  });

  if (!res.ok) {
    console.error('ElevenLabs TTS error', res.status, await res.text().catch(() => ''));
    return null;
  }

  const audio = await res.arrayBuffer();
  return { audio, contentType: 'audio/mpeg' };
}
