import { NextRequest, NextResponse } from 'next/server';
import { deleteDish, getDishesByRestaurant, upsertDish } from '@/lib/repository';
import { Dish } from '@/lib/types';

export const runtime = 'nodejs';

// GET /api/dishes?restaurantId=xxx — список блюд конкретного ресторана
export async function GET(req: NextRequest) {
  const restaurantId = req.nextUrl.searchParams.get('restaurantId');
  if (!restaurantId) {
    return NextResponse.json({ error: 'restaurantId обязателен' }, { status: 400 });
  }
  const dishes = await getDishesByRestaurant(restaurantId);
  return NextResponse.json({ dishes });
}

// POST /api/dishes — создать/обновить блюдо
// В продакшене здесь ДОЛЖНА быть проверка сессии админа и сверка, что
// dish.restaurantId совпадает с ресторана из его сессии (не из тела запроса).
export async function POST(req: NextRequest) {
  const dish = (await req.json()) as Dish;
  if (!dish.restaurantId || !dish.name) {
    return NextResponse.json({ error: 'restaurantId и name обязательны' }, { status: 400 });
  }
  const res = await upsertDish(dish);
  if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
  return NextResponse.json({ ok: true });
}

// DELETE /api/dishes?restaurantId=xxx&dishId=yyy
export async function DELETE(req: NextRequest) {
  const restaurantId = req.nextUrl.searchParams.get('restaurantId');
  const dishId = req.nextUrl.searchParams.get('dishId');
  if (!restaurantId || !dishId) {
    return NextResponse.json({ error: 'restaurantId и dishId обязательны' }, { status: 400 });
  }
  const res = await deleteDish(restaurantId, dishId);
  if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
  return NextResponse.json({ ok: true });
}
