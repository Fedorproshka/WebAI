-- Тестовые данные ресторана AURA (см. src/data/mockRestaurant.ts для полного
-- набора из 16 блюд, которые используются в DEMO-режиме без Supabase).
-- Этот файл — пример того, как загрузить тот же тестовый ресторан в реальную
-- базу Supabase. Дополните insert'ы блюд по аналогии с mockRestaurant.ts.

insert into restaurants (id, slug, name, description, currency)
values ('11111111-1111-1111-1111-111111111111', 'aura', 'AURA Restaurant',
  'Современная кухня на стыке средиземноморских и азиатских традиций.', '₸')
on conflict (slug) do nothing;

insert into ai_settings (restaurant_id, greeting, tone, upsell_enabled)
values ('11111111-1111-1111-1111-111111111111',
  'Не знаете, что выбрать? Расскажите немного о своих предпочтениях — AI подберёт блюда специально для вас.',
  'friendly', true)
on conflict (restaurant_id) do nothing;

-- Пример добавления одной категории и одного блюда — остальные 15 добавьте
-- через админ-панель (/admin/[restaurantId]/menu/new) либо аналогичными insert'ами.
insert into categories (id, restaurant_id, name, sort_order)
values ('22222222-2222-2222-2222-222222222222', '11111111-1111-1111-1111-111111111111', 'Основные блюда', 1)
on conflict do nothing;

insert into dishes (restaurant_id, category_id, name, description, price, ingredients, allergens, allergen_info_complete, tags, spice_level, is_available)
values (
  '11111111-1111-1111-1111-111111111111',
  '22222222-2222-2222-2222-222222222222',
  'Бургер AURA',
  'Говяжья котлета, чеддер, карамелизированный лук, соус табаско-майо',
  4200,
  array['говядина','булка бриошь','чеддер','лук','соус'],
  array['gluten','dairy','eggs'],
  true,
  array['meat'],
  1,
  true
);
