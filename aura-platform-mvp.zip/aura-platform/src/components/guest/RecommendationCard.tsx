'use client';

import Image from 'next/image';
import { DishRecommendation } from '@/lib/types';

interface Props {
  rec: DishRecommendation;
  rank: number;
  currency: string;
}

export default function RecommendationCard({ rec, rank, currency }: Props) {
  const { dish, matchScore, reason, allergenWarning } = rec;

  return (
    <div
      className="relative rounded-xl2 overflow-hidden bg-espresso-800/60 border border-parchment-200/10
                 animate-fadeUp"
      style={{ animationDelay: `${rank * 80}ms` }}
    >
      <div className="relative h-48 md:h-56 w-full bg-espresso-700">
        {dish.imageUrl && (
          <Image src={dish.imageUrl} alt={dish.name} fill className="object-cover" unoptimized />
        )}

        {/* Сигнатурный элемент: "печать" соответствия, как штамп шеф-повара */}
        <div className="absolute top-4 right-4 animate-stamp" style={{ animationDelay: `${rank * 80 + 200}ms` }}>
          <div
            className="w-16 h-16 rounded-full border-2 border-brass-400 bg-espresso-950/80 backdrop-blur
                       flex flex-col items-center justify-center -rotate-6 shadow-lg"
          >
            <span className="font-display italic text-lg text-brass-400 leading-none">{matchScore}%</span>
            <span className="text-[9px] uppercase tracking-wider text-parchment-200/60 mt-0.5">match</span>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="flex items-start justify-between gap-4">
          <h3 className="font-display italic text-xl text-parchment-50">{dish.name}</h3>
          <span className="shrink-0 font-medium text-brass-400">
            {dish.price.toLocaleString('ru-RU')} {currency}
          </span>
        </div>

        <p className="mt-2 text-sm text-parchment-200/60">{dish.description}</p>

        <p className="mt-3 text-xs text-parchment-200/40">
          {dish.ingredients.join(', ')}
        </p>

        <div className="mt-4 pt-4 border-t border-parchment-200/10">
          <p className="text-sm text-sage-400 leading-relaxed">{reason}</p>
        </div>

        {allergenWarning && (
          <div className="mt-3 flex items-start gap-2 rounded-lg bg-clay-500/10 border border-clay-500/30 px-3 py-2">
            <span className="text-clay-500 text-sm">⚠</span>
            <p className="text-xs text-parchment-100/80">{allergenWarning}</p>
          </div>
        )}
      </div>
    </div>
  );
}
