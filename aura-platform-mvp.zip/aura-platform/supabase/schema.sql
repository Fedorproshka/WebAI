-- =====================================================================
-- AURA AI PLATFORM — схема базы данных (multi-tenant)
-- Выполните этот файл в Supabase SQL Editor.
-- =====================================================================

create extension if not exists "uuid-ossp";

-- ---------- РЕСТОРАНЫ ----------
create table if not exists restaurants (
  id uuid primary key default uuid_generate_v4(),
  slug text unique not null,
  name text not null,
  description text default '',
  logo_url text,
  currency text default '₸',
  created_at timestamptz default now()
);

-- ---------- АДМИН-ПОЛЬЗОВАТЕЛИ (привязаны к auth.users Supabase) ----------
create table if not exists admin_users (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  restaurant_id uuid references restaurants(id) on delete cascade not null,
  role text default 'owner', -- owner | manager
  created_at timestamptz default now(),
  unique(user_id, restaurant_id)
);

-- ---------- КАТЕГОРИИ МЕНЮ ----------
create table if not exists categories (
  id uuid primary key default uuid_generate_v4(),
  restaurant_id uuid references restaurants(id) on delete cascade not null,
  name text not null,
  sort_order int default 0
);

-- ---------- БЛЮДА ----------
create table if not exists dishes (
  id uuid primary key default uuid_generate_v4(),
  restaurant_id uuid references restaurants(id) on delete cascade not null,
  category_id uuid references categories(id) on delete set null,
  name text not null,
  description text default '',
  price numeric not null default 0,
  image_url text,
  ingredients text[] default '{}',
  allergens text[] default '{}',
  allergen_info_complete boolean default true,
  tags text[] default '{}',
  spice_level int default 0 check (spice_level between 0 and 3),
  is_available boolean default true,
  created_at timestamptz default now()
);

create index if not exists idx_dishes_restaurant on dishes(restaurant_id);

-- ---------- НАСТРОЙКИ AI ----------
create table if not exists ai_settings (
  restaurant_id uuid primary key references restaurants(id) on delete cascade,
  greeting text default 'Не знаете, что выбрать? Расскажите немного о своих предпочтениях — AI подберёт блюда специально для вас.',
  tone text default 'friendly' check (tone in ('friendly','professional','playful')),
  upsell_enabled boolean default true,
  system_prompt_extra text default ''
);

-- ---------- ГОСТЕВЫЕ СЕССИИ И РЕКОМЕНДАЦИИ (для аналитики) ----------
create table if not exists guest_sessions (
  id uuid primary key default uuid_generate_v4(),
  restaurant_id uuid references restaurants(id) on delete cascade not null,
  answers jsonb not null,
  created_at timestamptz default now()
);

create table if not exists analytics_events (
  id uuid primary key default uuid_generate_v4(),
  restaurant_id uuid references restaurants(id) on delete cascade not null,
  type text not null, -- напр. 'recommendation_generated'
  payload jsonb default '{}',
  created_at timestamptz default now()
);

create index if not exists idx_events_restaurant on analytics_events(restaurant_id);

-- =====================================================================
-- ROW LEVEL SECURITY — жёсткая изоляция данных между ресторанами.
-- Публичные (гостевые) чтения разрешены только для доступных блюд/ресторана
-- по его id — гость никогда не получает список "все рестораны" целиком.
-- Запись (INSERT/UPDATE/DELETE) разрешена только admin_users текущего
-- restaurant_id. Сервисные вызовы из Route Handlers используют
-- service_role key и обходят RLS осознанно — поэтому там ОБЯЗАТЕЛЬНА
-- фильтрация по restaurant_id в коде (см. src/lib/repository.ts).
-- =====================================================================

alter table restaurants enable row level security;
alter table categories enable row level security;
alter table dishes enable row level security;
alter table ai_settings enable row level security;
alter table admin_users enable row level security;
alter table guest_sessions enable row level security;
alter table analytics_events enable row level security;

-- Публичное чтение ресторана по id/slug (нужно для гостевой страницы)
create policy "public read restaurants" on restaurants for select using (true);

-- Публичное чтение доступных блюд конкретного ресторана
create policy "public read available dishes" on dishes for select using (is_available = true);
create policy "public read categories" on categories for select using (true);
create policy "public read ai_settings" on ai_settings for select using (true);

-- Админы видят/меняют только данные СВОЕГО ресторана
create policy "admin manage own dishes" on dishes for all
  using (restaurant_id in (select restaurant_id from admin_users where user_id = auth.uid()))
  with check (restaurant_id in (select restaurant_id from admin_users where user_id = auth.uid()));

create policy "admin manage own categories" on categories for all
  using (restaurant_id in (select restaurant_id from admin_users where user_id = auth.uid()))
  with check (restaurant_id in (select restaurant_id from admin_users where user_id = auth.uid()));

create policy "admin manage own ai_settings" on ai_settings for all
  using (restaurant_id in (select restaurant_id from admin_users where user_id = auth.uid()))
  with check (restaurant_id in (select restaurant_id from admin_users where user_id = auth.uid()));

create policy "admin read own analytics" on analytics_events for select
  using (restaurant_id in (select restaurant_id from admin_users where user_id = auth.uid()));

create policy "admin read own restaurant row" on admin_users for select
  using (user_id = auth.uid());
