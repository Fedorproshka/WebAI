import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        espresso: {
          950: '#140F0C',
          900: '#1C1410',
          800: '#2A211B',
          700: '#3A2F27',
        },
        parchment: {
          50: '#FBF8F3',
          100: '#F3EDE2',
          200: '#E6DBC6',
        },
        brass: {
          400: '#D8B85A',
          500: '#C9A227',
          600: '#A9841D',
        },
        sage: {
          400: '#8FA079',
          500: '#7A8B69',
          600: '#647254',
        },
        clay: {
          500: '#B5603F',
        },
        forest: {
          50: '#F4F6F1',
          600: '#2F4B33',
          700: '#22371F',
          900: '#152414',
        },
      },
      fontFamily: {
        display: ['var(--font-fraunces)', 'serif'],
        body: ['var(--font-inter)', 'sans-serif'],
      },
      borderRadius: {
        xl2: '1.25rem',
      },
      keyframes: {
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        stamp: {
          '0%': { transform: 'scale(1.4) rotate(-8deg)', opacity: '0' },
          '100%': { transform: 'scale(1) rotate(-8deg)', opacity: '1' },
        },
        pulseRing: {
          '0%': { boxShadow: '0 0 0 0 rgba(181,96,63,0.45)' },
          '100%': { boxShadow: '0 0 0 14px rgba(181,96,63,0)' },
        },
      },
      animation: {
        fadeUp: 'fadeUp .5s ease-out both',
        stamp: 'stamp .4s cubic-bezier(.2,1.4,.4,1) both',
        pulseRing: 'pulseRing 1.4s ease-out infinite',
      },
    },
  },
  plugins: [],
};
export default config;
