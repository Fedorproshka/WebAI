'use client';

import { useState } from 'react';
import QuestionCard from './QuestionCard';
import AllergyStep from './AllergyStep';
import { Allergen, GuestPreferences } from '@/lib/types';

interface Props {
  onComplete: (prefs: GuestPreferences) => void;
}

const TOTAL_STEPS = 5;

export default function QuestionFlow({ onComplete }: Props) {
  const [step, setStep] = useState(1);
  const [craving, setCraving] = useState<GuestPreferences['craving'] | null>(null);
  const [hungerLevel, setHungerLevel] = useState<GuestPreferences['hungerLevel'] | null>(null);
  const [spice, setSpice] = useState<GuestPreferences['spice'] | null>(null);
  const [budget, setBudget] = useState<GuestPreferences['budget'] | null>(null);

  const back = () => setStep((s) => Math.max(1, s - 1));

  if (step === 1) {
    return (
      <QuestionCard
        step={1}
        totalSteps={TOTAL_STEPS}
        question="Что вам сейчас хочется?"
        options={[
          { value: 'meat', label: 'Мясо' },
          { value: 'fish', label: 'Рыба' },
          { value: 'pasta', label: 'Паста' },
          { value: 'light', label: 'Что-нибудь лёгкое' },
          { value: 'any', label: 'Не знаю' },
        ]}
        onSelect={(v) => {
          setCraving(v as GuestPreferences['craving']);
          setStep(2);
        }}
      />
    );
  }

  if (step === 2) {
    return (
      <QuestionCard
        step={2}
        totalSteps={TOTAL_STEPS}
        question="Насколько вы голодны?"
        options={[
          { value: 'light', label: 'Немного' },
          { value: 'medium', label: 'Средне' },
          { value: 'high', label: 'Очень' },
        ]}
        onSelect={(v) => {
          setHungerLevel(v as GuestPreferences['hungerLevel']);
          setStep(3);
        }}
        onBack={back}
      />
    );
  }

  if (step === 3) {
    return (
      <QuestionCard
        step={3}
        totalSteps={TOTAL_STEPS}
        question="Что вы предпочитаете?"
        options={[
          { value: 'mild', label: 'Не острое' },
          { value: 'medium', label: 'Немного острое' },
          { value: 'hot', label: 'Острые блюда' },
          { value: 'any', label: 'Без разницы' },
        ]}
        onSelect={(v) => {
          setSpice(v as GuestPreferences['spice']);
          setStep(4);
        }}
        onBack={back}
      />
    );
  }

  if (step === 4) {
    return (
      <QuestionCard
        step={4}
        totalSteps={TOTAL_STEPS}
        question="Какой бюджет?"
        options={[
          { value: 'under3000', label: 'До 3000 ₸' },
          { value: '3000-6000', label: '3000–6000 ₸' },
          { value: '6000-10000', label: '6000–10000 ₸' },
          { value: 'any', label: 'Без ограничений' },
        ]}
        onSelect={(v) => {
          setBudget(v as GuestPreferences['budget']);
          setStep(5);
        }}
        onBack={back}
      />
    );
  }

  return (
    <AllergyStep
      step={5}
      totalSteps={TOTAL_STEPS}
      onBack={back}
      onSubmit={(excludedIngredients, allergies: Allergen[]) => {
        onComplete({
          craving: craving ?? 'any',
          hungerLevel: hungerLevel ?? 'medium',
          spice: spice ?? 'any',
          budget: budget ?? 'any',
          excludedIngredients,
          allergies,
        });
      }}
    />
  );
}
